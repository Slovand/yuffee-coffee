<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Menu</title>
   <link rel="icon" href="images/favicon.ico" type="image/x-icon">

   <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <style>
      :root {
         --primary: #27ae60;
         --primary-dark: #219150;
         --bg: #f4f6fb;
         --white: #fff;
         --gray: #f0f1f6;
         --text: #222;
         --muted: #888;
         --shadow: 0 4px 24px rgba(40, 60, 90, 0.08);
      }
      html {
         scroll-behavior: smooth;
      }
      body {
         background: var(--bg);
         font-family: 'Poppins', Arial, sans-serif;
         color: var(--text);
         margin: 0;
         padding: 0;
      }
      .heading {
         background: var(--white);
         padding: 40px 0 30px 0;
         text-align: center;
         box-shadow: var(--shadow);
         margin-bottom: 40px;
         border-radius: 0 0 24px 24px;
      }
      .heading h3 {
         margin: 0;
         font-size: 2.7rem;
         color: var(--primary);
         letter-spacing: 2px;
         font-weight: 700;
      }
      .heading p {
         margin: 12px 0 0;
         color: var(--muted);
         font-size: 1.15rem;
      }
      .heading a {
         color: var(--primary);
         text-decoration: none;
         font-weight: 500;
         transition: color 0.2s;
      }
      .heading a:hover {
         color: var(--primary-dark);
      }
      .products {
         max-width: 1200px;
         margin: 0 auto;
         padding: 0 20px 40px 20px;
      }
      .products .title {
         text-align: center;
         font-size: 2.2rem;
         color: var(--text);
         margin-bottom: 36px;
         letter-spacing: 1px;
         font-weight: 600;
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
         gap: 32px;
      }
      .box {
         background: var(--white);
         border-radius: 18px;
         box-shadow: var(--shadow);
         padding: 28px 22px 22px 22px;
         display: flex;
         flex-direction: column;
         align-items: center;
         position: relative;
         transition: box-shadow 0.2s, transform 0.2s;
         min-height: 410px;
      }
      .box:hover {
         box-shadow: 0 8px 32px rgba(40, 60, 90, 0.14);
         transform: translateY(-6px) scale(1.025);
      }
      .box img {
         width: 150px;
         height: 150px;
         object-fit: cover;
         border-radius: 12px;
         margin-bottom: 18px;
         box-shadow: 0 2px 12px rgba(39,174,96,0.07);
         background: var(--gray);
         transition: box-shadow 0.2s;
      }
      .box img:hover {
         box-shadow: 0 4px 24px var(--primary);
      }
      .box .cat {
         background: var(--primary);
         color: var(--white);
         padding: 5px 18px;
         border-radius: 20px;
         font-size: 1rem;
         margin-bottom: 12px;
         text-decoration: none;
         font-weight: 500;
         letter-spacing: 0.5px;
         transition: background 0.2s;
      }
      .box .cat:hover {
         background: var(--primary-dark);
      }
      .box .name {
         font-size: 1.25rem;
         color: var(--text);
         margin-bottom: 12px;
         font-weight: 600;
         text-align: center;
         min-height: 48px;
         display: flex;
         align-items: center;
         justify-content: center;
      }
      .box .flex {
         display: flex;
         align-items: center;
         justify-content: space-between;
         width: 100%;
         margin-top: 18px;
      }
      .box .price {
         font-size: 1.15rem;
         color: var(--primary);
         font-weight: bold;
         letter-spacing: 0.5px;
      }
      .box .qty {
         width: 56px;
         padding: 7px 6px;
         border-radius: 7px;
         border: 1px solid #e0e0e0;
         text-align: center;
         font-size: 1rem;
         background: var(--gray);
         transition: border 0.2s;
      }
      .box .qty:focus {
         border: 1.5px solid var(--primary);
         outline: none;
      }
      .box .fas.fa-eye,
      .box .fas.fa-shopping-cart {
         position: absolute;
         top: 18px;
         font-size: 1.25rem;
         background: var(--gray);
         color: var(--primary);
         border-radius: 50%;
         width: 38px;
         height: 38px;
         display: flex;
         align-items: center;
         justify-content: center;
         transition: background 0.2s, color 0.2s, box-shadow 0.2s;
         cursor: pointer;
         z-index: 2;
         box-shadow: 0 2px 8px rgba(39,174,96,0.08);
         border: none;
      }
      .box .fas.fa-eye {
         left: 18px;
      }
      .box .fas.fa-shopping-cart {
         right: 18px;
      }
      .box .fas.fa-eye:hover,
      .box .fas.fa-shopping-cart:hover {
         background: var(--primary);
         color: var(--white);
         box-shadow: 0 4px 16px rgba(39,174,96,0.18);
      }
      .box button.fas.fa-shopping-cart {
         border: none;
         background: none;
         padding: 0;
      }
      .empty {
         text-align: center;
         color: var(--muted);
         font-size: 1.25rem;
         margin-top: 40px;
         font-weight: 500;
      }
      @media (max-width: 600px) {
         .heading h3 { font-size: 2rem; }
         .products .title { font-size: 1.4rem; }
         .box { padding: 18px 8px 16px 8px; min-height: 340px; }
         .box img { width: 110px; height: 110px; }
      }
   </style>
</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<div class="heading">
   <h3>Our Menu</h3>
   <p><a href="home.php">Home</a> <span> / Menu</span></p>
</div>

<!-- menu section starts  -->

<section class="products">

   <h1 class="title">Latest Dishes</h1>

   <div class="box-container">

      <?php
         if(!$conn){
            echo '<p class="empty">Database connection failed!</p>';
         } else {
            $select_products = $conn->prepare("SELECT * FROM `products`");
            $select_products->execute();
            if($select_products->rowCount() > 0){
               while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
      ?>
      <form action="" method="post" class="box">
         <input type="hidden" name="pid" value="<?= htmlspecialchars($fetch_products['id']); ?>">
         <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name']); ?>">
         <input type="hidden" name="price" value="<?= htmlspecialchars($fetch_products['price']); ?>">
         <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
         <a href="quick_view.php?pid=<?= htmlspecialchars($fetch_products['id']); ?>" class="fas fa-eye" title="Quick View"></a>
         <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" title="Add to Cart"></button>
         <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
         <a href="category.php?category=<?= urlencode($fetch_products['category']); ?>" class="cat"><?= htmlspecialchars($fetch_products['category']); ?></a>
         <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
         <div class="flex">
            <div class="price"><span>Rp</span><?= htmlspecialchars($fetch_products['price']); ?></div>
            <input type="number" name="qty" class="qty" min="1" max="99" value="1" maxlength="2" required>
         </div>
      </form>
      <?php
               }
            }else{
               echo '<p class="empty">No products added yet!</p>';
            }
         }
      ?>

   </div>

</section>

<!-- menu section ends -->

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>