<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Profile</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         font-family: 'Inter', Arial, sans-serif;
         background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
         min-height: 100vh;
         margin: 0;
         padding: 0;
      }
      .update-form {
         max-width: 420px;
         margin: 48px auto 32px auto;
         background: #fff;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(0,0,0,0.10);
         padding: 40px 32px 32px 32px;
         position: relative;
         z-index: 2;
      }
      .update-form h3 {
         margin-bottom: 22px;
         color: #22223b;
         font-weight: 600;
         font-size: 2rem;
         letter-spacing: 0.5px;
         text-align: center;
      }
      .update-form .box {
         width: 100%;
         margin-bottom: 18px;
         padding: 12px 14px;
         border: 1.5px solid #e0e7ef;
         border-radius: 8px;
         font-size: 1rem;
         background: #f7fafd;
         transition: border 0.2s, box-shadow 0.2s;
         color: #22223b;
      }
      .update-form .box:focus {
         border-color: #4f8cff;
         box-shadow: 0 0 0 2px #e3f0ff;
         outline: none;
         background: #fff;
      }
      .update-form .btn {
         width: 100%;
         padding: 14px;
         background: linear-gradient(90deg, #4f8cff 0%, #6a82fb 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         font-size: 1.1rem;
         font-weight: 600;
         cursor: pointer;
         transition: background 0.2s, box-shadow 0.2s;
         box-shadow: 0 2px 8px rgba(79,140,255,0.08);
         margin-top: 8px;
         letter-spacing: 0.5px;
      }
      .update-form .btn:hover {
         background: linear-gradient(90deg, #3b6ed6 0%, #4f8cff 100%);
         box-shadow: 0 4px 16px rgba(79,140,255,0.13);
      }
      .messages {
         margin-bottom: 18px;
      }
      .messages .msg {
         background: #ffeaea;
         color: #c0392b;
         border: 1px solid #ffd6d6;
         border-radius: 6px;
         padding: 10px 14px;
         margin-bottom: 8px;
         font-size: 1rem;
         box-shadow: 0 1px 4px rgba(220,53,69,0.04);
         transition: background 0.2s;
      }
      .messages .msg.success {
         background: #eafaf1;
         color: #218838;
         border-color: #c3e6cb;
      }
      @media (max-width: 600px) {
         .update-form {
            padding: 24px 8px 18px 8px;
            max-width: 98vw;
         }
         .update-form h3 {
            font-size: 1.3rem;
         }
      }
   </style>
</head>
<body style="background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);">
