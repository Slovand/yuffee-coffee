<?php
include 'components/connect.php';
session_start();

$user_id = $_SESSION['user_id'] ?? '';

include 'components/add_cart.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Quick View Item</title>
   <link rel="icon" href="images/favicon.ico" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         background: linear-gradient(120deg, #f8fafc 0%, #e0e7ff 100%);
         font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
         margin: 0;
         padding: 0;
         min-height: 100vh;
      }
      .quick-view {
         max-width: 520px;
         margin: 48px auto 48px auto;
         background: #fff;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(60,72,100,0.13);
         padding: 40px 32px 32px 32px;
         position: relative;
         overflow: hidden;
      }
      .quick-view:before {
         content: "";
         position: absolute;
         top: -60px; left: -60px;
         width: 180px; height: 180px;
         background: radial-gradient(circle at 60% 40%, #6c63ff22 60%, transparent 100%);
         z-index: 0;
      }
      .quick-view .title {
         text-align: center;
         font-size: 2.2rem;
         margin-bottom: 28px;
         color: #2d2d44;
         letter-spacing: 1.5px;
         font-weight: 700;
         position: relative;
         z-index: 1;
      }
      .quick-view .box {
         display: flex;
         flex-direction: column;
         align-items: center;
         gap: 22px;
         background: #f6f7fb;
         border-radius: 14px;
         padding: 32px 20px 28px 20px;
         box-shadow: 0 2px 12px rgba(108,99,255,0.06);
         transition: box-shadow 0.2s;
         position: relative;
         z-index: 1;
      }
      .quick-view .box:hover {
         box-shadow: 0 8px 32px rgba(108,99,255,0.13);
      }
      .quick-view img {
         width: 200px;
         height: 200px;
         object-fit: cover;
         border-radius: 12px;
         border: 2px solid #e0e7ff;
         background: #fff;
         box-shadow: 0 2px 8px rgba(76,110,245,0.07);
         transition: transform 0.2s;
      }
      .quick-view img:hover {
         transform: scale(1.04) rotate(-2deg);
      }
      .quick-view .cat {
         font-size: 1rem;
         color: #6c63ff;
         text-decoration: none;
         margin-bottom: 4px;
         font-weight: 600;
         letter-spacing: 0.7px;
         background: #e0e7ff;
         padding: 4px 14px;
         border-radius: 16px;
         transition: background 0.2s, color 0.2s;
      }
      .quick-view .cat:hover {
         background: #6c63ff;
         color: #fff;
      }
      .quick-view .name {
         font-size: 1.5rem;
         font-weight: 700;
         color: #22223b;
         margin-bottom: 10px;
         text-align: center;
         letter-spacing: 0.5px;
      }
      .quick-view .flex {
         display: flex;
         align-items: center;
         gap: 24px;
         width: 100%;
         justify-content: center;
         margin-bottom: 8px;
      }
      .quick-view .price {
         font-size: 1.3rem;
         color: #27ae60;
         font-weight: 700;
         background: #eafaf1;
         padding: 6px 18px;
         border-radius: 8px;
         box-shadow: 0 1px 4px rgba(39,174,96,0.07);
      }
      .quick-view .qty {
         width: 64px;
         padding: 7px 10px;
         border-radius: 8px;
         border: 1.5px solid #bfc9ff;
         font-size: 1.1rem;
         text-align: center;
         background: #fff;
         transition: border 0.2s;
      }
      .quick-view .qty:focus {
         border: 1.5px solid #6c63ff;
         outline: none;
      }
      .quick-view .cart-btn {
         background: linear-gradient(90deg, #6c63ff 0%, #48c6ef 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         padding: 12px 38px;
         font-size: 1.15rem;
         font-weight: 600;
         cursor: pointer;
         transition: background 0.2s, box-shadow 0.2s;
         margin-top: 14px;
         box-shadow: 0 2px 8px rgba(76,110,245,0.08);
         letter-spacing: 0.5px;
         display: flex;
         align-items: center;
         gap: 10px;
      }
      .quick-view .cart-btn:hover {
         background: linear-gradient(90deg, #48c6ef 0%, #6c63ff 100%);
         box-shadow: 0 4px 16px rgba(76,110,245,0.13);
      }
      .empty {
         text-align: center;
         color: #888;
         font-size: 1.15rem;
         margin: 48px 0;
         background: #f6f7fb;
         border-radius: 10px;
         padding: 32px 0;
         box-shadow: 0 2px 8px rgba(60,72,100,0.06);
      }
      @media (max-width: 700px) {
         .quick-view {
            padding: 18px 2vw;
         }
         .quick-view img {
            width: 120px;
            height: 120px;
         }
         .quick-view .box {
            padding: 18px 6px 16px 6px;
         }
      }
      @media (max-width: 480px) {
         .quick-view {
            margin: 18px 0;
         }
         .quick-view .title {
            font-size: 1.3rem;
         }
      }
   </style>
</head>
<body>
<?php include 'components/user_header.php'; ?>

<section class="quick-view">
   <h1 class="title"><i class="fa fa-eye"></i> Quick View</h1>
   <?php
      if(isset($_GET['pid']) && is_numeric($_GET['pid'])){
         $pid = (int)$_GET['pid'];
         $select_products = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
         if($select_products->execute([$pid])){
            if($select_products->rowCount() > 0){
               $fetch_products = $select_products->fetch(PDO::FETCH_ASSOC);
   ?>
   <form action="" method="post" class="box" autocomplete="off">
      <input type="hidden" name="pid" value="<?= htmlspecialchars($fetch_products['id']); ?>">
      <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name']); ?>">
      <input type="hidden" name="price" value="<?= htmlspecialchars($fetch_products['price']); ?>">
      <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
      <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
      <a href="category.php?category=<?= urlencode($fetch_products['category']); ?>" class="cat"><?= htmlspecialchars($fetch_products['category']); ?></a>
      <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
      <div class="flex">
         <div class="price"><span>Rp</span><?= htmlspecialchars($fetch_products['price']); ?></div>
         <input type="number" name="qty" class="qty" min="1" max="99" value="1" oninput="if(this.value.length>2)this.value=this.value.slice(0,2);">
      </div>
      <button type="submit" name="add_to_cart" class="cart-btn"><i class="fa fa-cart-plus"></i> Add to Cart</button>
   </form>
   <?php
            } else {
               echo '<p class="empty"><i class="fa fa-box-open"></i> No products found!</p>';
            }
         } else {
            echo '<p class="empty"><i class="fa fa-exclamation-triangle"></i> Error fetching product!</p>';
         }
      } else {
         echo '<p class="empty"><i class="fa fa-exclamation-circle"></i> Invalid product ID!</p>';
      }
   ?>
</section>

<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
