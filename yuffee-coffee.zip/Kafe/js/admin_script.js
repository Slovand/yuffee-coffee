// admin_script.js

// Utility functions for class manipulation
const toggleClass = (el, cls) => el?.classList.toggle(cls);
const addClass = (el, cls) => el?.classList.add(cls);
const removeClass = (el, cls) => el?.classList.remove(cls);

// DOM Elements
const profile = document.querySelector('.header .flex .profile');
const navbar = document.querySelector('.header .flex .navbar');
const userBtn = document.getElementById('user-btn');
const menuBtn = document.getElementById('menu-btn');
const mainImage = document.querySelector('.update-product .image-container .main-image img');
const subImages = document.querySelectorAll('.update-product .image-container .sub-images img');

// Handle menu toggling with accessibility improvements
userBtn?.addEventListener('click', e => {
   e.stopPropagation();
   toggleClass(profile, 'active');
   removeClass(navbar, 'active');
   userBtn.setAttribute('aria-expanded', profile?.classList.contains('active'));
});

menuBtn?.addEventListener('click', e => {
   e.stopPropagation();
   toggleClass(navbar, 'active');
   removeClass(profile, 'active');
   menuBtn.setAttribute('aria-expanded', navbar?.classList.contains('active'));
});

// Close menus on scroll or click outside
const closeMenus = () => {
   removeClass(profile, 'active');
   removeClass(navbar, 'active');
   userBtn?.setAttribute('aria-expanded', 'false');
   menuBtn?.setAttribute('aria-expanded', 'false');
};
window.addEventListener('scroll', closeMenus);
document.addEventListener('click', e => {
   if (!profile?.contains(e.target) && !userBtn?.contains(e.target)) removeClass(profile, 'active');
   if (!navbar?.contains(e.target) && !menuBtn?.contains(e.target)) removeClass(navbar, 'active');
   userBtn?.setAttribute('aria-expanded', 'false');
   menuBtn?.setAttribute('aria-expanded', 'false');
});

// Main image gallery with smooth transitions
if (mainImage && subImages.length) {
   subImages.forEach(img => {
      img.addEventListener('click', () => {
         if (mainImage.src !== img.src) {
            addClass(mainImage, 'fade-out');
            setTimeout(() => {
               mainImage.src = img.src;
               removeClass(mainImage, 'fade-out');
               addClass(mainImage, 'fade-in');
               setTimeout(() => removeClass(mainImage, 'fade-in'), 300);
            }, 200);
         }
         // Highlight selected thumbnail
         subImages.forEach(i => removeClass(i, 'selected'));
         addClass(img, 'selected');
      });
   });
}

// Optional: Keyboard navigation for accessibility
document.addEventListener('keydown', e => {
   if (e.key === 'Escape') closeMenus();
});