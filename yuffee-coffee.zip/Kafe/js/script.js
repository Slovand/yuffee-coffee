// Utility functions with null checks
const $ = (selector, ctx = document) => ctx?.querySelector(selector) || null;
const $$ = (selector, ctx = document) => Array.from(ctx?.querySelectorAll(selector) || []);

// DOM Elements with null checks
const elements = {
  navbar: $('.header .flex .navbar'),
  profile: $('.header .flex .profile'),
  menuBtn: $('#menu-btn'),
  userBtn: $('#user-btn'),
  loader: $('.loader')
};

// Helper: Close all dropdown menus
function closeMenus() {
  elements.navbar?.classList.remove('active');
  elements.profile?.classList.remove('active');
}

// Initialize event listeners
function initEventListeners() {
  // Menu button toggle
  elements.menuBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    elements.navbar?.classList.toggle('active');
    elements.profile?.classList.remove('active');
  });

  // Profile button toggle
  elements.userBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    elements.profile?.classList.toggle('active');
    elements.navbar?.classList.remove('active');
  });

  // Close menus on scroll
  window.addEventListener('scroll', () => {
    closeMenus();
  }, { passive: true });

  // Close menus when clicking outside
  document.addEventListener('click', (e) => {
    if (!elements.navbar?.contains(e.target) && !elements.menuBtn?.contains(e.target)) {
      elements.navbar?.classList.remove('active');
    }
    if (!elements.profile?.contains(e.target) && !elements.userBtn?.contains(e.target)) {
      elements.profile?.classList.remove('active');
    }
  });

  // Close menus with Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeMenus();
    }
  });

  // Handle number inputs
  $$('input[type="number"]').forEach(input => {
    input.addEventListener('input', () => {
      const maxLength = input.getAttribute('maxlength');
      if (maxLength && input.value.length > maxLength) {
        input.value = input.value.slice(0, maxLength);
      }
    });
  });
}

// Loader animation with fade out
// Loader animation with fade out
function handleLoader() {
    const loader = elements.loader; // Menggunakan elements.loader yang sudah didefinisikan

    if (!loader) {
        console.warn('Loader element not found. Skipping loader animation.');
        return;
    }

    // Pastikan loader terlihat di awal
    loader.style.opacity = '1';
    loader.style.display = 'flex'; // Atau 'grid', tergantung layout CSS Anda

    const fadeOutDelay = 1000; // 1 detik sebelum fade out dimulai
    // Durasi transisi opacity dari CSS (misal: 0.8s = 800ms)
    const transitionDuration = 800; // Sesuaikan dengan 'transition: opacity 0.8s' di CSS

    setTimeout(() => {
        // Tambahkan class untuk memulai transisi fade out
        loader.classList.add('fade-out');

        // Sembunyikan loader setelah transisi selesai
        setTimeout(() => {
            loader.style.display = 'none';
            loader.classList.remove('fade-out'); // Opsional: bersihkan class untuk penggunaan di masa depan
        }, transitionDuration);
    }, fadeOutDelay);
}

// ... sisa kode script.js ...

// Initialize everything when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  initEventListeners();
  handleLoader();
});

// Optional: Clean up event listeners when needed
function cleanup() {
  // You can add specific cleanup logic here if needed
}