<?php
include 'components/connect.php';
session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   header('location:home.php');
   exit;
}

// Fetch user profile from database
$fetch_profile = [];
$stmt = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
$stmt->execute([$user_id]);
if($stmt->rowCount() > 0){
   $fetch_profile = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
   $fetch_profile = [
      'name' => 'Unknown',
      'number' => '',
      'email' => '',
      'address' => ''
   ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Profile</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         background: linear-gradient(135deg, #e0e7ff 0%, #f4f6f8 100%);
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         margin: 0;
         min-height: 100vh;
      }
      .user-details {
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 80vh;
         padding: 2rem 0;
      }
      .user {
         background: #fff;
         padding: 2.5rem 2.5rem 2rem 2.5rem;
         border-radius: 1.5rem;
         box-shadow: 0 8px 32px rgba(60,72,88,0.12), 0 1.5px 4px rgba(0,0,0,0.04);
         text-align: center;
         max-width: 400px;
         width: 100%;
         transition: box-shadow 0.2s;
         position: relative;
      }
      .user:hover {
         box-shadow: 0 12px 40px rgba(60,72,88,0.18), 0 2px 8px rgba(0,0,0,0.06);
      }
      .user img {
         width: 100px;
         height: 100px;
         border-radius: 50%;
         margin-bottom: 1.5rem;
         border: 4px solid #e0e7ff;
         object-fit: cover;
         background: #f4f6f8;
         box-shadow: 0 2px 8px rgba(60,72,88,0.08);
      }
      .user h2 {
         margin: 0.5rem 0 0.2rem 0;
         font-size: 1.5rem;
         color: #22223b;
         font-weight: 700;
         letter-spacing: 0.5px;
      }
      .user p {
         margin: 0.7rem 0;
         font-size: 1.08rem;
         color: #444;
         display: flex;
         align-items: center;
         justify-content: center;
         gap: 0.6rem;
         font-weight: 500;
         letter-spacing: 0.1px;
      }
      .user .address {
         margin-top: 1.3rem;
         color: #666;
         font-size: 1.02rem;
         background: #f8fafc;
         border-radius: 0.7rem;
         padding: 0.7rem 1rem;
         display: flex;
         align-items: center;
         justify-content: center;
         gap: 0.6rem;
         min-height: 48px;
      }
      .user .btn {
         display: inline-block;
         margin: 0.8rem 0.3rem 0 0.3rem;
         padding: 0.55rem 1.7rem;
         background: linear-gradient(90deg, #6366f1 0%, #2563eb 100%);
         color: #fff;
         border-radius: 2rem;
         text-decoration: none;
         font-weight: 600;
         font-size: 1.05rem;
         box-shadow: 0 2px 8px rgba(60,72,88,0.08);
         border: none;
         transition: background 0.2s, box-shadow 0.2s;
         cursor: pointer;
      }
      .user .btn:hover, .user .btn:focus {
         background: linear-gradient(90deg, #2563eb 0%, #6366f1 100%);
         box-shadow: 0 4px 16px rgba(60,72,88,0.14);
         outline: none;
      }
      .user .icon {
         color: #6366f1;
         font-size: 1.15rem;
         min-width: 22px;
         text-align: center;
      }
      @media (max-width: 500px) {
         .user {
            padding: 1.2rem 0.7rem 1rem 0.7rem;
            max-width: 98vw;
         }
         .user img {
            width: 75px;
            height: 75px;
         }
      }
   </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="user-details">
   <div class="user" aria-label="User Profile">
      <img src="images/user-icon.png" alt="User Icon">
      <h2><?= htmlspecialchars($fetch_profile['name']); ?></h2>
      <p><span class="icon"><i class="fas fa-phone"></i></span><?= htmlspecialchars($fetch_profile['number']); ?></p>
      <p><span class="icon"><i class="fas fa-envelope"></i></span><?= htmlspecialchars($fetch_profile['email']); ?></p>
      <a href="update_profile.php" class="btn" aria-label="Update Info"><i class="fas fa-user-edit"></i> Update Info</a>
      <p class="address"><span class="icon"><i class="fas fa-map-marker-alt"></i></span>
         <span>
            <?php
               if(empty($fetch_profile['address'])){
                  echo 'Please enter your address';
               }else{
                  echo htmlspecialchars($fetch_profile['address']);
               }
            ?>
         </span>
      </p>
      <a href="update_address.php" class="btn" aria-label="Update Address"><i class="fas fa-location-arrow"></i> Update Address</a>
   </div>
</section>

<?php include 'components/footer.php'; ?>
<script src="js/script.js"></script>
</body>
</html>
