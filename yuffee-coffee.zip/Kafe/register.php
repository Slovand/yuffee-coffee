<?php
include 'components/connect.php';
session_start();

$user_id = $_SESSION['user_id'] ?? '';
$message = [];

if (isset($_POST['submit'])) {
   $name = trim(filter_var($_POST['name'], FILTER_SANITIZE_STRING));
   $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
   $number = trim(filter_var($_POST['number'], FILTER_SANITIZE_STRING));
   $pass_input = $_POST['pass'];
   $cpass_input = $_POST['cpass'];

   // Password validation
   if (strlen($pass_input) < 6) {
      $message[] = 'Password must be at least 6 characters!';
   } elseif ($pass_input !== $cpass_input) {
      $message[] = 'Confirm password not matched!';
   } else {
      try {
         $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ? OR number = ?");
         $select_user->execute([$email, $number]);

         if ($select_user->rowCount() > 0) {
            $message[] = 'Email or number already exists!';
         } else {
            $pass_hash = password_hash($pass_input, PASSWORD_DEFAULT);

            $insert_user = $conn->prepare("INSERT INTO `users` (name, email, number, password) VALUES (?, ?, ?, ?)");
            $insert_user->execute([$name, $email, $number, $pass_hash]);

            $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
            $select_user->execute([$email]);
            $row = $select_user->fetch(PDO::FETCH_ASSOC);

            if ($row && password_verify($pass_input, $row['password'])) {
               $_SESSION['user_id'] = $row['id'];
               header('location:home.php');
               exit;
            }
         }
      } catch (PDOException $e) {
         $message[] = 'Database error: ' . $e->getMessage();
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         background-image: url('images/food-1024x683.jpg');
         background-size: cover;
         background-position: center;
         background-repeat: no-repeat;
         min-height: 100vh;
         margin: 0;
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }
      .form-container {
         max-width: 400px;
         margin: 60px auto 40px auto;
         background: rgba(255,255,255,0.95);
         border-radius: 16px;
         box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.2);
         padding: 32px 28px 24px 28px;
      }
      .form-container h3 {
         text-align: center;
         margin-bottom: 24px;
         color: #333;
         font-weight: 600;
         letter-spacing: 1px;
      }
      .form-container .box {
         width: 100%;
         padding: 12px 14px;
         margin: 10px 0;
         border: 1px solid #ccc;
         border-radius: 8px;
         font-size: 16px;
         background: #f9f9f9;
         transition: border 0.2s;
      }
      .form-container .box:focus {
         border: 1.5px solid #007bff;
         outline: none;
      }
      .form-container .btn {
         width: 100%;
         padding: 12px;
         background: linear-gradient(90deg, #ffb347 0%, #ffcc33 100%);
         border: none;
         border-radius: 8px;
         color: #fff;
         font-size: 18px;
         font-weight: 600;
         cursor: pointer;
         margin-top: 10px;
         transition: background 0.2s;
      }
      .form-container .btn:hover {
         background: linear-gradient(90deg, #ffcc33 0%, #ffb347 100%);
      }
      .form-container p {
         text-align: center;
         margin-top: 18px;
         color: #555;
      }
      .form-container a {
         color: #ffb347;
         text-decoration: none;
         font-weight: 500;
      }
      .form-container a:hover {
         text-decoration: underline;
      }
      .message {
         background: #ffe0e0;
         color: #d8000c;
         border: 1px solid #d8000c;
         border-radius: 6px;
         padding: 10px 14px;
         margin-bottom: 10px;
         text-align: center;
         font-size: 15px;
      }
   </style>
</head>
<body>
<?php include 'components/user_header.php'; ?>

<section class="form-container">
   <form action="" method="post" autocomplete="off">
      <h3><i class="fa fa-user-plus"></i> Register Now</h3>
      <?php
      if (!empty($message)) {
         foreach ($message as $msg) {
            echo '<div class="message">'.$msg.'</div>';
         }
      }
      ?>
      <input type="text" name="name" required placeholder="Full Name" class="box" maxlength="50" autofocus>
      <input type="email" name="email" required placeholder="Email Address" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="text" name="number" required placeholder="Mobile Number (10 digits)" class="box" pattern="\d{10}" maxlength="10" title="Enter 10 digit number">
      <input type="password" name="pass" required placeholder="Password (min 6 chars)" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="cpass" required placeholder="Confirm Password" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="Register Now" name="submit" class="btn">
      <p>Already have an account? <a href="login.php">Login now</a></p>
   </form>
</section>

<?php include 'components/footer.php'; ?>
<script src="js/script.js"></script>
</body>
</html>
