<?php

include 'components/connect.php';

session_start();

$user_id = $_SESSION['user_id'] ?? '';

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Food Category</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <style>
      body {
         background: linear-gradient(135deg, #f8fafc 0%, #e3e6f3 100%);
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         margin: 0;
         padding: 0;
      }
      .products {
         max-width: 1200px;
         margin: 48px auto 32px auto;
         padding: 32px 24px;
         background: #fff;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(60,72,88,0.13);
      }
      .products .title {
         text-align: center;
         font-size: 2.7rem;
         color: #22223b;
         margin-bottom: 38px;
         letter-spacing: 1.5px;
         font-weight: 700;
         text-transform: capitalize;
         position: relative;
      }
      .products .title::after {
         content: '';
         display: block;
         margin: 18px auto 0 auto;
         width: 80px;
         height: 4px;
         border-radius: 2px;
         background: linear-gradient(90deg, #27ae60 60%, #4ecca3 100%);
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
         gap: 36px;
      }
      .box {
         background: #f9f9fb;
         border-radius: 14px;
         box-shadow: 0 2px 16px rgba(60,72,88,0.08);
         padding: 26px 20px 22px 20px;
         display: flex;
         flex-direction: column;
         align-items: center;
         transition: box-shadow 0.22s, transform 0.22s;
         position: relative;
         overflow: hidden;
      }
      .box:hover {
         box-shadow: 0 8px 32px rgba(76,204,163,0.13);
         transform: translateY(-4px) scale(1.025);
      }
      .box img {
         width: 100%;
         max-width: 180px;
         height: 140px;
         object-fit: cover;
         border-radius: 10px;
         margin-bottom: 18px;
         background: #e9ecef;
         box-shadow: 0 2px 8px rgba(60,72,88,0.06);
         transition: transform 0.18s;
      }
      .box:hover img {
         transform: scale(1.04);
      }
      .box .name {
         font-size: 1.18rem;
         font-weight: 600;
         color: #22223b;
         margin-bottom: 10px;
         text-align: center;
         letter-spacing: 0.5px;
      }
      .box .flex {
         display: flex;
         justify-content: space-between;
         align-items: center;
         width: 100%;
         margin-top: 12px;
      }
      .box .price {
         font-size: 1.13rem;
         color: #27ae60;
         font-weight: bold;
         letter-spacing: 0.5px;
      }
      .box .qty {
         width: 60px;
         padding: 6px 8px;
         border-radius: 6px;
         border: 1px solid #cfd8dc;
         text-align: center;
         font-size: 1rem;
         background: #fff;
         transition: border 0.18s;
      }
      .box .qty:focus {
         border: 1.5px solid #27ae60;
         outline: none;
      }
      .box .fa-eye, .box .fa-shopping-cart {
         position: absolute;
         top: 18px;
         font-size: 1.18rem;
         color: #4ecca3;
         background: #fff;
         border-radius: 50%;
         width: 38px;
         height: 38px;
         display: flex;
         align-items: center;
         justify-content: center;
         transition: background 0.2s, color 0.2s, box-shadow 0.2s;
         cursor: pointer;
         border: none;
         outline: none;
         box-shadow: 0 1px 6px rgba(60,72,88,0.07);
         z-index: 2;
      }
      .box .fa-eye {
         left: 18px;
      }
      .box .fa-shopping-cart {
         right: 18px;
      }
      .box .fa-eye:hover, .box .fa-shopping-cart:hover {
         background: linear-gradient(135deg, #27ae60 60%, #4ecca3 100%);
         color: #fff;
         box-shadow: 0 2px 12px rgba(76,204,163,0.13);
      }
      .empty {
         text-align: center;
         color: #888;
         font-size: 1.22rem;
         margin: 48px 0;
         letter-spacing: 0.5px;
      }
      @media (max-width: 600px) {
         .products {
            padding: 12px 2vw;
         }
         .products .title {
            font-size: 2rem;
         }
         .box-container {
            gap: 18px;
         }
         .box {
            padding: 16px 8px 14px 8px;
         }
      }
   </style>
</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="products">

   <h1 class="title">Food Category</h1>

   <div class="box-container">

      <?php
         if(isset($_GET['category']) && !empty($_GET['category'])){
            $category = htmlspecialchars($_GET['category'], ENT_QUOTES, 'UTF-8');
            $select_products = $conn->prepare("SELECT * FROM `products` WHERE category = ?");
            $select_products->execute([$category]);
            if($select_products->rowCount() > 0){
               while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
      ?>
      <form action="" method="post" class="box" autocomplete="off">
         <input type="hidden" name="pid" value="<?= htmlspecialchars($fetch_products['id'], ENT_QUOTES, 'UTF-8'); ?>">
         <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name'], ENT_QUOTES, 'UTF-8'); ?>">
         <input type="hidden" name="price" value="<?= htmlspecialchars($fetch_products['price'], ENT_QUOTES, 'UTF-8'); ?>">
         <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image'], ENT_QUOTES, 'UTF-8'); ?>">
         <a href="quick_view.php?pid=<?= urlencode($fetch_products['id']); ?>" class="fas fa-eye" title="Quick View" aria-label="Quick View"></a>
         <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" title="Add to Cart" aria-label="Add to Cart"></button>
         <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?= htmlspecialchars($fetch_products['name'], ENT_QUOTES, 'UTF-8'); ?>">
         <div class="name"><?= htmlspecialchars($fetch_products['name'], ENT_QUOTES, 'UTF-8'); ?></div>
         <div class="flex">
            <div class="price"><span>Rp</span><?= htmlspecialchars($fetch_products['price'], ENT_QUOTES, 'UTF-8'); ?></div>
            <input type="number" name="qty" class="qty" min="1" max="99" value="1" maxlength="2" aria-label="Quantity">
         </div>
      </form>
      <?php
               }
            }else{
               echo '<p class="empty">No products found in this category!</p>';
            }
         }else{
            echo '<p class="empty">No category selected!</p>';
         }
      ?>

   </div>

</section>

<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>
