<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:home.php');
   exit;
}

// Fetch user profile
$fetch_profile = [];
$select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
$select_profile->execute([$user_id]);
if($select_profile->rowCount() > 0){
   $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
} else {
   header('location:home.php');
   exit;
}

$message = [];

if(isset($_POST['submit'])){

   $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
   $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
   $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
   $method = filter_var($_POST['method'], FILTER_SANITIZE_STRING);
   $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
   $total_products = $_POST['total_products'];
   $total_price = $_POST['total_price'];

   $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $check_cart->execute([$user_id]);

   if($check_cart->rowCount() > 0){

      if($address == ''){
         $message[] = 'Please add your address!';
      }else{
         $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?,?)");
         $insert_order->execute([$user_id, $name, $number, $email, $method, $address, $total_products, $total_price]);

         $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
         $delete_cart->execute([$user_id]);

         $message[] = 'Order placed successfully!';
      }

   }else{
      $message[] = 'Your cart is empty';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Checkout</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <style>
      :root {
         --primary: #2d3436;
         --accent: #e17055;
         --accent-dark: #d35400;
         --bg: #f5f6fa;
         --white: #fff;
         --shadow: 0 4px 24px rgba(44,62,80,0.07);
         --radius: 14px;
         --input-bg: #f1f2f6;
         --input-border: #dfe4ea;
         --success: #00b894;
         --warning: #fdcb6e;
         --danger: #d63031;
      }
      body {
         background: var(--bg);
         font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
         margin: 0;
         color: var(--primary);
      }
      .heading {
         background: linear-gradient(90deg, var(--accent), var(--accent-dark));
         color: var(--white);
         padding: 36px 0 24px 0;
         text-align: center;
         border-radius: 0 0 var(--radius) var(--radius);
         box-shadow: var(--shadow);
         margin-bottom: 32px;
      }
      .heading h3 {
         margin: 0 0 8px 0;
         font-size: 2.2rem;
         letter-spacing: 1px;
      }
      .heading p {
         margin: 0;
         font-size: 1.1rem;
         opacity: 0.9;
      }
      .heading a {
         color: var(--white);
         text-decoration: underline;
         font-weight: 500;
      }
      .checkout {
         max-width: 600px;
         margin: 0 auto 40px auto;
         background: var(--white);
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         padding: 36px 32px 32px 32px;
      }
      .title {
         font-size: 1.7rem;
         font-weight: 600;
         margin-bottom: 24px;
         color: var(--accent-dark);
         letter-spacing: 1px;
         text-align: center;
      }
      .cart-items, .user-info {
         margin-bottom: 32px;
         padding-bottom: 18px;
         border-bottom: 1px solid #ececec;
      }
      .cart-items h3, .user-info h3 {
         color: var(--accent);
         margin-bottom: 12px;
         font-size: 1.15rem;
         font-weight: 600;
      }
      .cart-items p, .user-info p {
         margin: 10px 0;
         font-size: 1rem;
         display: flex;
         align-items: center;
         gap: 10px;
      }
      .grand-total {
         font-weight: bold;
         color: var(--success);
         font-size: 1.1rem;
         margin-top: 18px;
      }
      .btn {
         display: inline-block;
         padding: 10px 22px;
         background: linear-gradient(90deg, var(--accent), var(--accent-dark));
         color: var(--white);
         border-radius: 6px;
         text-decoration: none;
         margin-top: 12px;
         font-weight: 500;
         font-size: 1rem;
         border: none;
         cursor: pointer;
         transition: background 0.2s, box-shadow 0.2s;
         box-shadow: 0 2px 8px #0001;
      }
      .btn:hover, .btn:focus {
         background: linear-gradient(90deg, var(--accent-dark), var(--accent));
         box-shadow: 0 4px 16px #0002;
      }
      .box, select {
         width: 100%;
         padding: 12px 14px;
         margin: 12px 0;
         border-radius: 7px;
         border: 1px solid var(--input-border);
         background: var(--input-bg);
         font-size: 1rem;
         transition: border 0.2s;
         outline: none;
      }
      .box:focus, select:focus {
         border: 1.5px solid var(--accent);
         background: #fff;
      }
      .disabled {
         opacity: 0.6;
         pointer-events: none;
      }
      .message {
         background: var(--warning);
         color: var(--primary);
         padding: 12px 18px;
         border-radius: 7px;
         margin-bottom: 18px;
         font-size: 1rem;
         box-shadow: 0 2px 8px #0001;
      }
      .empty {
         color: #b2bec3;
         font-style: italic;
         font-size: 1.05rem;
      }
      .user-info i {
         color: var(--accent-dark);
         min-width: 22px;
         text-align: center;
      }
      select {
         appearance: none;
         background: var(--input-bg) url('data:image/svg+xml;utf8,<svg fill="gray" height="20" viewBox="0 0 20 20" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M7.293 7.293a1 1 0 011.414 0L10 8.586l1.293-1.293a1 1 0 111.414 1.414l-2 2a1 1 0 01-1.414 0l-2-2a1 1 0 010-1.414z"/></svg>') no-repeat right 14px center/18px 18px;
      }
      @media (max-width: 700px) {
         .checkout {
            padding: 18px 6vw 22px 6vw;
         }
      }
      @media (max-width: 500px) {
         .checkout {
            padding: 10px 2vw 14px 2vw;
         }
         .heading {
            padding: 22px 0 14px 0;
         }
      }
   </style>
</head>
<body>
<?php include 'components/user_header.php'; ?>

<div class="heading">
   <h3>Checkout</h3>
   <p><a href="home.php">Home</a> <span> / Checkout</span></p>
</div>

<section class="checkout">

   <?php
   if(!empty($message)){
      foreach($message as $msg){
         echo '<div class="message">'.htmlspecialchars($msg).'</div>';
      }
   }
   ?>

   <h1 class="title">Order Summary</h1>

<form action="" method="post">

   <div class="cart-items">
      <h3>Cart Items</h3>
      <?php
         $grand_total = 0;
         $cart_items = [];
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
               $cart_items[] = $fetch_cart['name'].' ('.$fetch_cart['price'].' x '. $fetch_cart['quantity'].')';
               $grand_total += ($fetch_cart['price'] * $fetch_cart['quantity']);
      ?>
      <p>
         <span class="name"><?= htmlspecialchars($fetch_cart['name']); ?></span>
         <span class="price">Rp<?= htmlspecialchars($fetch_cart['price']); ?> x <?= htmlspecialchars($fetch_cart['quantity']); ?></span>
      </p>
      <?php
            }
            $total_products = implode(' - ', $cart_items);
         }else{
            echo '<p class="empty">Your cart is empty!</p>';
            $total_products = '';
         }
      ?>
      <p class="grand-total">
         <span class="name">Grand Total :</span>
         <span class="price">Rp<?= $grand_total; ?></span>
      </p>
      <a href="cart.php" class="btn">View Cart</a>
   </div>

   <input type="hidden" name="total_products" value="<?= htmlspecialchars($total_products); ?>">
   <input type="hidden" name="total_price" value="<?= $grand_total; ?>">
   <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_profile['name']) ?>">
   <input type="hidden" name="number" value="<?= htmlspecialchars($fetch_profile['number']) ?>">
   <input type="hidden" name="email" value="<?= htmlspecialchars($fetch_profile['email']) ?>">
   <input type="hidden" name="address" value="<?= htmlspecialchars($fetch_profile['address']) ?>">

   <div class="user-info">
      <h3>Your Info</h3>
      <p><i class="fas fa-user"></i> <span><?= htmlspecialchars($fetch_profile['name']) ?></span></p>
      <p><i class="fas fa-phone"></i> <span><?= htmlspecialchars($fetch_profile['number']) ?></span></p>
      <p><i class="fas fa-envelope"></i> <span><?= htmlspecialchars($fetch_profile['email']) ?></span></p>
      <a href="update_profile.php" class="btn">Update Info</a>
      <h3>Delivery Address</h3>
      <p><i class="fas fa-map-marker-alt"></i>
         <span>
            <?php
               if($fetch_profile['address'] == ''){
                  echo 'Please enter your address';
               }else{
                  echo htmlspecialchars($fetch_profile['address']);
               }
            ?>
         </span>
      </p>
      <a href="update_address.php" class="btn">Update Address</a>
      <select name="method" class="box" required>
         <option value="" disabled selected>Select payment method --</option>
         <option value="cash on delivery">Cash on Delivery</option>
         <option value="credit card">Credit Card</option>
         <option value="paytm">Paytm</option>
         <option value="paypal">Paypal</option>
      </select>
      <input type="submit" value="Place Order" class="btn <?php if($fetch_profile['address'] == ''){echo 'disabled';} ?>" style="width:100%;" name="submit">
   </div>

</form>
   
</section>

<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>