<?php
include 'components/connect.php';
session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
}

$message = [];
$name = $email = $number = $msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send'])) {
   // CSRF protection
   if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
      $message[] = 'Invalid CSRF token!';
   } else {
      $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
      $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
      $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
      $msg = filter_var($_POST['msg'], FILTER_SANITIZE_STRING);

      $select_message = $conn->prepare("SELECT * FROM `messages` WHERE name = ? AND email = ? AND number = ? AND message = ?");
      $select_message->execute([$name, $email, $number, $msg]);

      if($select_message->rowCount() > 0){
         $message[] = 'You have already sent this message!';
      }else{
         $insert_message = $conn->prepare("INSERT INTO `messages`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
         $insert_message->execute([$user_id, $name, $email, $number, $msg]);
         $message[] = 'Message sent successfully!';
         $name = $email = $number = $msg = '';
      }
   }
}

// Generate CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact Us!</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         min-height: 100vh;
         margin: 0;
         font-family: 'Inter', Arial, sans-serif;
         background: linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%);
         position: relative;
         overflow-x: hidden;
      }
      /* Animated gradient overlay */
      body::before {
         content: '';
         position: fixed;
         top: 0; left: 0; right: 0; bottom: 0;
         z-index: 0;
         background: linear-gradient(120deg, rgba(108,99,255,0.18) 0%, rgba(72,198,239,0.18) 100%);
         animation: gradientMove 8s ease-in-out infinite alternate;
         pointer-events: none;
      }
      @keyframes gradientMove {
         0% { background-position: 0% 50%; }
         100% { background-position: 100% 50%; }
      }
      .heading {
         text-align: center;
         margin-top: 40px;
         z-index: 1;
         position: relative;
      }
      .heading h3 {
         color: #222;
         font-size: 2.5rem;
         font-weight: 600;
         letter-spacing: 1px;
         margin-bottom: 8px;
      }
      .heading p {
         color: #6c63ff;
         font-size: 1.1rem;
         margin-bottom: 0;
      }
      .heading a {
         color: #48c6ef;
         text-decoration: none;
         font-weight: 500;
      }
      .heading span {
         color: #222;
         opacity: 0.7;
      }
      .contact {
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 80vh;
         z-index: 1;
         position: relative;
      }
      .contact .row {
         background: rgba(255,255,255,0.85);
         border-radius: 22px;
         box-shadow: 0 8px 32px 0 rgba(31,38,135,0.18);
         backdrop-filter: blur(8px);
         -webkit-backdrop-filter: blur(8px);
         padding: 40px 32px;
         max-width: 900px;
         width: 100%;
         margin: 40px 16px;
         display: flex;
         gap: 48px;
         align-items: center;
         transition: box-shadow 0.2s;
      }
      .contact .row:hover {
         box-shadow: 0 12px 40px 0 rgba(31,38,135,0.22);
      }
      .contact .image img {
         max-width: 320px;
         border-radius: 14px;
         box-shadow: 0 2px 12px rgba(72,198,239,0.12);
         display: block;
      }
      .contact form {
         flex: 1;
         display: flex;
         flex-direction: column;
         gap: 18px;
         z-index: 1;
      }
      .contact h3 {
         font-size: 2rem;
         color: #6c63ff;
         margin-bottom: 10px;
         font-weight: 600;
         letter-spacing: 0.5px;
      }
      .input-group {
         position: relative;
         display: flex;
         align-items: center;
      }
      .input-group i {
         position: absolute;
         left: 14px;
         color: #6c63ff;
         font-size: 1.1rem;
         opacity: 0.8;
      }
      .contact .box, .contact textarea {
         border: none;
         border-radius: 8px;
         padding: 12px 14px 12px 38px;
         font-size: 1.08rem;
         width: 100%;
         background: rgba(245,245,255,0.95);
         color: #222;
         box-shadow: 0 1px 4px rgba(108,99,255,0.04);
         transition: box-shadow 0.18s, border 0.18s;
         outline: none;
      }
      .contact .box:focus, .contact textarea:focus {
         box-shadow: 0 2px 8px rgba(72,198,239,0.13);
         border: 1.5px solid #6c63ff;
         background: #fff;
      }
      .contact textarea {
         min-height: 110px;
         resize: vertical;
         padding-left: 38px;
      }
      .contact .btn {
         background: linear-gradient(90deg, #6c63ff 0%, #48c6ef 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         padding: 14px;
         font-size: 1.15rem;
         font-weight: 600;
         cursor: pointer;
         box-shadow: 0 2px 8px rgba(108,99,255,0.08);
         transition: background 0.18s, box-shadow 0.18s;
         letter-spacing: 0.5px;
      }
      .contact .btn:hover {
         background: linear-gradient(90deg, #48c6ef 0%, #6c63ff 100%);
         box-shadow: 0 4px 16px rgba(72,198,239,0.13);
      }
      .message {
         background: linear-gradient(90deg, #6c63ff 0%, #48c6ef 100%);
         color: #fff;
         padding: 14px 24px;
         border-radius: 8px;
         margin: 18px auto 0 auto;
         max-width: 600px;
         text-align: center;
         font-size: 1.13rem;
         box-shadow: 0 2px 12px rgba(108,99,255,0.10);
         position: relative;
         animation: fadeIn 0.6s;
         display: flex;
         align-items: center;
         justify-content: center;
      }
      .message .close-btn {
         position: absolute;
         right: 14px;
         top: 10px;
         background: none;
         border: none;
         color: #fff;
         font-size: 1.2rem;
         cursor: pointer;
         opacity: 0.7;
         transition: opacity 0.15s;
      }
      .message .close-btn:hover {
         opacity: 1;
      }
      @keyframes fadeIn {
         from { opacity: 0; transform: translateY(-20px);}
         to { opacity: 1; transform: translateY(0);}
      }
      @media (max-width: 1000px) {
         .contact .row { flex-direction: column; gap: 28px; padding: 32px 12px;}
         .contact .image img { max-width: 100%; }
      }
      @media (max-width: 600px) {
         .heading h3 { font-size: 1.5rem;}
         .contact .row { padding: 18px 4px; }
         .contact h3 { font-size: 1.2rem;}
      }
   </style>
</head>
<body style="background-image: url('images/coffee-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
<?php include 'components/user_header.php'; ?>

<div class="heading">
   <h3>Contact Us</h3>
   <p><a href="home.php">home</a> <span> / contact</span></p>
</div>

<!-- Display messages -->
<?php
if(!empty($message)){
   foreach($message as $msg){
      echo '<div class="message">'.htmlspecialchars($msg).'<button class="close-btn" onclick="this.parentElement.style.display=\'none\'"><i class=\'fas fa-times\'></i></button></div>';
   }
}
?>

<section class="contact">
   <div class="row">
      <div class="image">
         <img src="images/contact-img.svg" alt="Contact">
      </div>
      <form action="" method="post" autocomplete="off" id="contactForm">
         <h3>Tell us something!</h3>
         <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
         <div class="input-group">
            <i class="fas fa-user"></i>
            <input type="text" name="name" maxlength="50" class="box" placeholder="Enter your name" required value="<?php echo htmlspecialchars($name); ?>">
         </div>
         <div class="input-group">
            <i class="fas fa-phone"></i>
            <input type="tel" name="number" pattern="[0-9]{10}" class="box" placeholder="Enter your number" required maxlength="10" value="<?php echo htmlspecialchars($number); ?>">
         </div>
         <div class="input-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" maxlength="50" class="box" placeholder="Enter your email" required value="<?php echo htmlspecialchars($email); ?>">
         </div>
         <div class="input-group">
            <i class="fas fa-comment-dots"></i>
            <textarea name="msg" class="box" required placeholder="Enter your message" maxlength="500" cols="30" rows="6"><?php echo htmlspecialchars($msg); ?></textarea>
         </div>
         <input type="submit" value="Send Message" name="send" class="btn">
      </form>
   </div>
</section>

<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>
<script>
   // Auto-hide messages after 4 seconds
   setTimeout(function() {
      document.querySelectorAll('.message').forEach(function(el) {
         el.style.opacity = '0';
         setTimeout(function(){ el.style.display = 'none'; }, 600);
      });
   }, 4000);

   // Client-side validation for phone number
   document.getElementById('contactForm').addEventListener('submit', function(e) {
      var number = document.querySelector('input[name="number"]').value;
      if (!/^\d{10}$/.test(number)) {
         alert('Please enter a valid 10-digit phone number.');
         e.preventDefault();
      }
   });
</script>
</body>
</html>
