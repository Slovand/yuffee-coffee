<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_message = $conn->prepare("DELETE FROM `messages` WHERE id = ?");
   $delete_message->execute([$delete_id]);
   header('location:messages.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Messages</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
   <style>
      body {
         background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
         min-height: 100vh;
         font-family: 'Segoe UI', Arial, sans-serif;
         margin: 0;
         padding: 0;
      }
      .messages {
         max-width: 900px;
         margin: 40px auto 0 auto;
         background: #fff;
         border-radius: 16px;
         box-shadow: 0 8px 32px rgba(60,72,88,0.12);
         padding: 40px 30px 30px 30px;
      }
      .messages .heading {
         font-size: 2.2rem;
         font-weight: 700;
         color: #2d3748;
         margin-bottom: 30px;
         letter-spacing: 1px;
         text-align: center;
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
         gap: 24px;
      }
      .box {
         background: #f7fafc;
         border-radius: 12px;
         box-shadow: 0 2px 8px rgba(60,72,88,0.08);
         padding: 24px 20px;
         transition: box-shadow 0.2s;
         position: relative;
         border-left: 5px solid #4f8cff;
      }
      .box:hover {
         box-shadow: 0 6px 24px rgba(60,72,88,0.16);
         border-left: 5px solid #2563eb;
      }
      .box p {
         margin: 0 0 10px 0;
         color: #374151;
         font-size: 1.05rem;
         line-height: 1.5;
      }
      .box span {
         color: #2563eb;
         font-weight: 600;
         word-break: break-all;
      }
      .delete-btn {
         display: inline-block;
         margin-top: 12px;
         padding: 8px 18px;
         background: #ef4444;
         color: #fff;
         border-radius: 6px;
         font-size: 1rem;
         font-weight: 500;
         text-decoration: none;
         transition: background 0.2s;
         box-shadow: 0 2px 8px rgba(239,68,68,0.08);
         border: none;
         cursor: pointer;
      }
      .delete-btn:hover {
         background: #b91c1c;
      }
      .empty {
         text-align: center;
         color: #6b7280;
         font-size: 1.2rem;
         padding: 40px 0;
      }
      @media (max-width: 600px) {
         .messages {
            padding: 18px 6px 18px 6px;
         }
         .box {
            padding: 16px 8px;
         }
      }
   </style>
</head>
<body style="background-image: url('images/kopi.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php include '../components/admin_header.php' ?>

<section class="messages">
   <h1 class="heading"><i class="fa-solid fa-envelope-open-text"></i> Messages</h1>
   <div class="box-container">
   <?php
      $select_messages = $conn->prepare("SELECT * FROM `messages` ORDER BY id DESC");
      $select_messages->execute();
      if($select_messages->rowCount() > 0){
         while($fetch_messages = $select_messages->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="box">
      <p><i class="fa-solid fa-user"></i> Name: <span><?= htmlspecialchars($fetch_messages['name']); ?></span></p>
      <p><i class="fa-solid fa-phone"></i> Number: <span><?= htmlspecialchars($fetch_messages['number']); ?></span></p>
      <p><i class="fa-solid fa-envelope"></i> Email: <span><?= htmlspecialchars($fetch_messages['email']); ?></span></p>
      <p><i class="fa-solid fa-comment-dots"></i> Message: <span><?= nl2br(htmlspecialchars($fetch_messages['message'])); ?></span></p>
      <a href="messages.php?delete=<?= $fetch_messages['id']; ?>" class="delete-btn" onclick="return confirm('Delete this message?');"><i class="fa-solid fa-trash"></i> Delete</a>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty"><i class="fa-solid fa-inbox"></i> You have no messages</p>';
      }
   ?>
   </div>
</section>

<script src="../js/admin_script.js"></script>
</body>
</html>