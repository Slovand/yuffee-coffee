<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_users = $conn->prepare("DELETE FROM `users` WHERE id = ?");
   $delete_users->execute([$delete_id]);
   $delete_order = $conn->prepare("DELETE FROM `orders` WHERE user_id = ?");
   $delete_order->execute([$delete_id]);
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart->execute([$delete_id]);
   header('location:users_accounts.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Users Accounts</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
   <style>
      body {
         background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
         min-height: 100vh;
         font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
         margin: 0;
         padding: 0;
      }
      .accounts {
         max-width: 900px;
         margin: 40px auto 0 auto;
         background: #fff;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(60,72,100,0.15);
         padding: 40px 30px 30px 30px;
      }
      .accounts .heading {
         text-align: center;
         font-size: 2.2rem;
         color: #2d3748;
         margin-bottom: 30px;
         letter-spacing: 1px;
         font-weight: 700;
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
         gap: 24px;
      }
      .box {
         background: linear-gradient(120deg, #f0f4fa 0%, #e9eefa 100%);
         border-radius: 14px;
         box-shadow: 0 2px 8px rgba(60,72,100,0.07);
         padding: 28px 22px;
         display: flex;
         flex-direction: column;
         align-items: flex-start;
         transition: box-shadow 0.2s;
         position: relative;
      }
      .box:hover {
         box-shadow: 0 8px 24px rgba(60,72,100,0.18);
      }
      .box p {
         margin: 0 0 10px 0;
         font-size: 1.08rem;
         color: #4a5568;
      }
      .box p span {
         color: #2b6cb0;
         font-weight: 600;
      }
      .delete-btn {
         margin-top: 10px;
         padding: 8px 18px;
         background: linear-gradient(90deg, #f56565 0%, #e53e3e 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         font-size: 1rem;
         font-weight: 500;
         cursor: pointer;
         text-decoration: none;
         transition: background 0.2s, box-shadow 0.2s;
         box-shadow: 0 2px 6px rgba(229,62,62,0.07);
         display: inline-flex;
         align-items: center;
         gap: 6px;
      }
      .delete-btn:hover {
         background: linear-gradient(90deg, #e53e3e 0%, #c53030 100%);
         box-shadow: 0 4px 12px rgba(229,62,62,0.15);
      }
      .empty {
         grid-column: 1/-1;
         text-align: center;
         color: #a0aec0;
         font-size: 1.2rem;
         margin-top: 30px;
      }
      @media (max-width: 600px) {
         .accounts {
            padding: 18px 5px;
         }
         .accounts .heading {
            font-size: 1.3rem;
         }
      }
   </style>
</head>
<body style="background-image: url('images/kopi.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php include '../components/admin_header.php' ?>

<section class="accounts">
   <h1 class="heading"><i class="fas fa-users"></i> Users Accounts</h1>
   <div class="box-container">
   <?php
      $select_account = $conn->prepare("SELECT * FROM `users`");
      $select_account->execute();
      if($select_account->rowCount() > 0){
         while($fetch_accounts = $select_account->fetch(PDO::FETCH_ASSOC)){  
   ?>
   <div class="box">
      <p><i class="fas fa-id-badge"></i> User ID: <span><?= htmlspecialchars($fetch_accounts['id']); ?></span></p>
      <p><i class="fas fa-user"></i> Username: <span><?= htmlspecialchars($fetch_accounts['name']); ?></span></p>
      <a href="users_accounts.php?delete=<?= $fetch_accounts['id']; ?>" class="delete-btn" onclick="return confirm('Delete this account?');">
         <i class="fas fa-trash-alt"></i> Delete
      </a>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty"><i class="fas fa-user-slash"></i> No accounts available</p>';
   }
   ?>
   </div>
</section>

<script src="../js/admin_script.js"></script>
</body>
</html>