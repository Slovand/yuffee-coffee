<?php
include '../components/connect.php';
session_start();

$admin_id = $_SESSION['admin_id'] ?? ''; // Menggunakan null coalescing operator untuk menghindari undefined index
if(empty($admin_id)){ // Memeriksa apakah $admin_id kosong
    header('location:admin_login.php');
    exit;
}

$message = []; // Inisialisasi array pesan

if(isset($_POST['update'])){
    $pid = filter_var($_POST['pid'], FILTER_SANITIZE_STRING);
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $price = filter_var($_POST['price'], FILTER_SANITIZE_STRING);
    $category = filter_var($_POST['category'], FILTER_SANITIZE_STRING);

    // Update data produk (nama, kategori, harga)
    $update_product = $conn->prepare("UPDATE `products` SET name = ?, category = ?, price = ? WHERE id = ?");
    $update_product->execute([$name, $category, $price, $pid]);
    $message[] = ['type' => 'success', 'text' => 'Produk berhasil diperbarui!'];

    $old_image = $_POST['old_image'] ?? ''; // Menggunakan null coalescing operator
    $image = $_FILES['image']['name'] ?? ''; // Menggunakan null coalescing operator
    $image_size = $_FILES['image']['size'] ?? 0;
    $image_tmp_name = $_FILES['image']['tmp_name'] ?? '';
    $image_folder = '../uploaded_img/'.$image;

    if(!empty($image)){
        if($image_size > 2000000){ // Batasan ukuran gambar
            $message[] = ['type' => 'error', 'text' => 'Ukuran gambar terlalu besar!'];
        } else {
            // Memindahkan gambar baru dan menghapus gambar lama
            if(move_uploaded_file($image_tmp_name, $image_folder)){
                $update_image = $conn->prepare("UPDATE `products` SET image = ? WHERE id = ?");
                $update_image->execute([$image, $pid]);
                if($old_image && file_exists('../uploaded_img/'.$old_image)){
                    unlink('../uploaded_img/'.$old_image); // Hapus gambar lama
                }
                $message[] = ['type' => 'success', 'text' => 'Gambar produk berhasil diperbarui!'];
            } else {
                $message[] = ['type' => 'error', 'text' => 'Gagal mengunggah gambar!'];
            }
        }
    }
}

// Ambil ID produk dari parameter URL
$update_id = $_GET['update'] ?? '';
$fetch_products = null; // Inisialisasi null

if (!empty($update_id)) {
    $show_products = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
    $show_products->execute([$update_id]);
    if($show_products->rowCount() > 0){
        $fetch_products = $show_products->fetch(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perbarui Produk | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* CSS Anda yang sudah ada */
        :root {
            --primary: #4f8cff;
            --primary-dark: #2563eb;
            --bg: #f7f9fb;
            --white: #fff;
            --gray: #e5e7eb;
            --text: #22223b;
            --success: #22c55e;
            --error: #ef4444;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', Arial, sans-serif;
        }
        body {
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }
        .update-product {
            max-width: 480px;
            margin: 40px auto;
            background: var(--white);
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            padding: 32px 28px;
        }
        .heading {
            text-align: center;
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 24px;
            color: var(--primary-dark);
            letter-spacing: 1px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }
        form img {
            display: block;
            margin: 0 auto 10px auto;
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 12px;
            border: 2px solid var(--gray);
            background: var(--gray);
        }
        label, span {
            font-size: 1rem;
            font-weight: 500;
            margin-bottom: 4px;
            color: #444;
        }
        .box, select {
            width: 100%;
            padding: 10px 12px;
            border: 1.5px solid var(--gray);
            border-radius: 8px;
            background: #f9fafb;
            font-size: 1rem;
            transition: border-color 0.2s;
            margin-bottom: 6px;
        }
        .box:focus, select:focus {
            border-color: var(--primary);
            outline: none;
        }
        .flex-btn {
            display: flex;
            gap: 12px;
            margin-top: 10px;
        }
        .btn, .option-btn {
            flex: 1;
            padding: 10px 0;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-align: center;
            text-decoration: none;
        }
        .btn {
            background: var(--primary);
            color: var(--white);
        }
        .btn:hover {
            background: var(--primary-dark);
        }
        .option-btn {
            background: var(--gray);
            color: var(--primary-dark);
        }
        .option-btn:hover {
            background: var(--primary-dark);
            color: var(--white);
        }
        .messages {
            margin-bottom: 18px;
        }
        .message {
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 8px;
            font-size: 0.98rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .message.success {
            background: #e7fbe9;
            color: var(--success);
            border: 1px solid var(--success);
        }
        .message.error {
            background: #fbe7e7;
            color: var(--error);
            border: 1px solid var(--error);
        }
        .empty {
            text-align: center;
            color: var(--text);
            font-size: 1.1rem;
            padding: 20px;
            background: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        @media (max-width: 600px) {
            .update-product {
                padding: 18px 6vw;
            }
            .heading {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body style="background-image: url('images/kopi.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
<?php include '../components/admin_header.php' ?>

<section class="update-product">
    <h1 class="heading">Perbarui Produk</h1>
    <?php if(!empty($message)): ?>
        <div class="messages">
            <?php foreach($message as $msg): ?>
                <div class="message <?= htmlspecialchars($msg['type']); ?>">
                    <?php if($msg['type'] === 'success'): ?>
                        <i class="fa-solid fa-circle-check"></i>
                    <?php else: ?>
                        <i class="fa-solid fa-circle-exclamation"></i>
                    <?php endif; ?>
                    <?= htmlspecialchars($msg['text']); ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if($fetch_products): ?>
        <form action="" method="POST" enctype="multipart/form-data" autocomplete="off">
            <input type="hidden" name="pid" value="<?= htmlspecialchars($fetch_products['id']); ?>">
            <input type="hidden" name="old_image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
            <img src="../uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="Gambar Produk">
            <label for="name">Nama Produk</label>
            <input type="text" required placeholder="Masukkan nama produk" name="name" id="name" maxlength="100" class="box" value="<?= htmlspecialchars($fetch_products['name']); ?>">
            <label for="price">Harga</label>
            <input type="number" min="0" max="9999999999" required placeholder="Masukkan harga produk" name="price" id="price" onkeypress="if(this.value.length == 10) return false;" class="box" value="<?= htmlspecialchars($fetch_products['price']); ?>">
            <label for="category">Kategori</label>
            <select name="category" class="box" id="category" required>
                <option selected value="<?= htmlspecialchars($fetch_products['category']); ?>"><?= htmlspecialchars(ucwords($fetch_products['category'])); ?></option>
                <?php
                    $categories = ['main dish', 'fast food', 'drinks', 'desserts'];
                    foreach($categories as $cat):
                        if($cat !== $fetch_products['category']): // Hanya tampilkan kategori yang belum terpilih
                ?>
                    <option value="<?= htmlspecialchars($cat); ?>"><?= htmlspecialchars(ucwords($cat)); ?></option>
                <?php
                        endif;
                    endforeach;
                ?>
            </select>
            <label for="image">Gambar Produk</label>
            <input type="file" name="image" id="image" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
            <div class="flex-btn">
                <input type="submit" value="Perbarui" class="btn" name="update">
                <a href="products.php" class="option-btn">Kembali</a>
            </div>
        </form>
    <?php else: ?>
        <p class="empty">Tidak ada produk ditemukan!</p>
    <?php endif; ?>
</section>

<script src="../js/admin_script.js"></script>
</body>
</html>