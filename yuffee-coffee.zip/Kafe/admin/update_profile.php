<?php
include '../components/connect.php';
session_start();

$admin_id = $_SESSION['admin_id'] ?? null;
if (!$admin_id) {
   header('location:admin_login.php');
   exit;
}

// Fetch current profile info
$stmt = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
$stmt->execute([$admin_id]);
$fetch_profile = $stmt->fetch(PDO::FETCH_ASSOC);

$messages = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $name = trim($_POST['name'] ?? '');
   $name = filter_var($name, FILTER_SANITIZE_STRING);

   // Update name if changed and not taken
   if (!empty($name) && $name !== $fetch_profile['name']) {
      $select_name = $conn->prepare("SELECT id FROM `admin` WHERE name = ? AND id != ?");
      $select_name->execute([$name, $admin_id]);
      if ($select_name->rowCount() > 0) {
         $messages[] = ['type' => 'error', 'text' => 'Username already taken!'];
      } else {
         $update_name = $conn->prepare("UPDATE `admin` SET name = ? WHERE id = ?");
         $update_name->execute([$name, $admin_id]);
         $messages[] = ['type' => 'success', 'text' => 'Username updated!'];
         $fetch_profile['name'] = $name;
      }
   }

   // Password update
   $old_pass = $_POST['old_pass'] ?? '';
   $new_pass = $_POST['new_pass'] ?? '';
   $confirm_pass = $_POST['confirm_pass'] ?? '';

   if ($old_pass || $new_pass || $confirm_pass) {
      if (empty($old_pass) || empty($new_pass) || empty($confirm_pass)) {
         $messages[] = ['type' => 'error', 'text' => 'Please fill all password fields.'];
      } else {
         $old_pass_hashed = sha1($old_pass);
         if ($old_pass_hashed !== $fetch_profile['password']) {
            $messages[] = ['type' => 'error', 'text' => 'Old password not matched!'];
         } elseif ($new_pass !== $confirm_pass) {
            $messages[] = ['type' => 'error', 'text' => 'Confirm password not matched!'];
         } elseif (strlen($new_pass) < 6) {
            $messages[] = ['type' => 'error', 'text' => 'New password must be at least 6 characters.'];
         } else {
            $new_pass_hashed = sha1($new_pass);
            if ($new_pass_hashed === $fetch_profile['password']) {
               $messages[] = ['type' => 'error', 'text' => 'New password cannot be the same as old password.'];
            } else {
               $update_pass = $conn->prepare("UPDATE `admin` SET password = ? WHERE id = ?");
               $update_pass->execute([$new_pass_hashed, $admin_id]);
               $messages[] = ['type' => 'success', 'text' => 'Password updated successfully!'];
            }
         }
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Admin Profile Update</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
   <style>
      body {
         background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
         min-height: 100vh;
         font-family: 'Segoe UI', Arial, sans-serif;
         margin: 0;
      }
      .form-container {
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 80vh;
      }
      .profile-card {
         background: #fff;
         padding: 2.5rem 2rem 2rem 2rem;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(60, 72, 88, 0.18);
         max-width: 400px;
         width: 100%;
         margin: 2rem 0;
      }
      .profile-card h3 {
         text-align: center;
         margin-bottom: 1.5rem;
         color: #2d3748;
         font-weight: 600;
         letter-spacing: 1px;
      }
      .profile-card .box {
         width: 100%;
         padding: 0.9rem 1rem;
         margin-bottom: 1.1rem;
         border: 1px solid #cbd5e1;
         border-radius: 8px;
         font-size: 1rem;
         background: #f8fafc;
         transition: border-color 0.2s;
      }
      .profile-card .box:focus {
         border-color: #4f8cff;
         outline: none;
         background: #fff;
      }
      .profile-card .btn {
         width: 100%;
         padding: 0.9rem;
         background: linear-gradient(90deg, #4f8cff 0%, #38b6ff 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         font-size: 1.1rem;
         font-weight: 600;
         cursor: pointer;
         transition: background 0.2s;
         margin-top: 0.5rem;
      }
      .profile-card .btn:hover {
         background: linear-gradient(90deg, #38b6ff 0%, #4f8cff 100%);
      }
      .messages {
         margin-bottom: 1.2rem;
      }
      .message {
         padding: 0.8rem 1rem;
         border-radius: 6px;
         margin-bottom: 0.7rem;
         font-size: 0.98rem;
         display: flex;
         align-items: center;
         gap: 0.7rem;
      }
      .message.success {
         background: #e6fffa;
         color: #0f766e;
         border: 1px solid #2dd4bf;
      }
      .message.error {
         background: #fff1f2;
         color: #b91c1c;
         border: 1px solid #f87171;
      }
      @media (max-width: 500px) {
         .profile-card {
            padding: 1.2rem 0.7rem;
         }
      }
   </style>
</head>
<body>
<?php include '../components/admin_header.php' ?>

<section class="form-container">
   <form class="profile-card" action="" method="POST" autocomplete="off">
      <h3><i class="fa-solid fa-user-pen"></i> Update Profile</h3>
      <?php if (!empty($messages)): ?>
         <div class="messages">
            <?php foreach ($messages as $msg): ?>
               <div class="message <?= htmlspecialchars($msg['type']) ?>">
                  <?php if ($msg['type'] === 'success'): ?>
                     <i class="fa-solid fa-circle-check"></i>
                  <?php else: ?>
                     <i class="fa-solid fa-circle-exclamation"></i>
                  <?php endif; ?>
                  <?= htmlspecialchars($msg['text']) ?>
               </div>
            <?php endforeach; ?>
         </div>
      <?php endif; ?>
      <input
         type="text"
         name="name"
         maxlength="20"
         class="box"
         value="<?= htmlspecialchars($fetch_profile['name'] ?? '') ?>"
         placeholder="Your username"
         required
         oninput="this.value = this.value.replace(/\s/g, '')"
      >
      <input
         type="password"
         name="old_pass"
         maxlength="20"
         placeholder="Current password"
         class="box"
         autocomplete="off"
         oninput="this.value = this.value.replace(/\s/g, '')"
      >
      <input
         type="password"
         name="new_pass"
         maxlength="20"
         placeholder="New password (min 6 chars)"
         class="box"
         autocomplete="off"
         oninput="this.value = this.value.replace(/\s/g, '')"
      >
      <input
         type="password"
         name="confirm_pass"
         maxlength="20"
         placeholder="Confirm new password"
         class="box"
         autocomplete="off"
         oninput="this.value = this.value.replace(/\s/g, '')"
      >
      <button type="submit" name="submit" class="btn">
         <i class="fa-solid fa-floppy-disk"></i> Update Now
      </button>
   </form>
</section>

<script src="../js/admin_script.js"></script>
</body>
</html>