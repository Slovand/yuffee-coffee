<?php
include '../components/connect.php';
session_start();

$admin_id = $_SESSION['admin_id'] ?? '';
if(!$admin_id){
   header('location:admin_login.php');
   exit;
}

$message = [];

if(isset($_POST['submit'])){
   $name = trim($_POST['name']);
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = $_POST['pass'];
   $cpass = $_POST['cpass'];

   $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE name = ?");
   $select_admin->execute([$name]);
   
   if($select_admin->rowCount() > 0){
      $message[] = 'Username already exists!';
   } else {
      if($pass !== $cpass){
         $message[] = 'Confirm password does not match!';
      } else {
         // Gunakan SHA1 untuk kompatibilitas
         $hashed_pass = sha1($pass);
         $insert_admin = $conn->prepare("INSERT INTO `admin`(name, password) VALUES(?,?)");
         $insert_admin->execute([$name, $hashed_pass]);
         $message[] = 'New admin registered successfully!';
      }
   }
}
?>

<!-- Bagian HTML tetap sama -->

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register as Admin</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="../css/admin_style.css">
   <style>
      body {
         min-height: 100vh;
         margin: 0;
         font-family: 'Inter', Arial, sans-serif;
         background: linear-gradient(rgba(30,30,30,0.7), rgba(30,30,30,0.7)), url('images/food-1024x683.jpg') center/cover no-repeat;
         display: flex;
         flex-direction: column;
         align-items: center;
         justify-content: center;
      }
      .form-container {
         display: flex;
         justify-content: center;
         align-items: center;
         min-height: 100vh;
      }
      form {
         background: rgba(255,255,255,0.92);
         padding: 2.5rem 2rem 2rem 2rem;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(0,0,0,0.18);
         width: 100%;
         max-width: 370px;
         display: flex;
         flex-direction: column;
         gap: 1.2rem;
      }
      form h3 {
         text-align: center;
         font-weight: 600;
         color: #222;
         margin-bottom: 0.5rem;
         letter-spacing: 1px;
      }
      .box {
         padding: 0.85rem 1rem;
         border: 1px solid #e0e0e0;
         border-radius: 8px;
         font-size: 1rem;
         background: #f9f9f9;
         transition: border-color 0.2s;
      }
      .box:focus {
         border-color: #4e9cff;
         outline: none;
         background: #fff;
      }
      .btn {
         background: linear-gradient(90deg, #4e9cff 0%, #38c172 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         padding: 0.9rem 0;
         font-size: 1.08rem;
         font-weight: 600;
         cursor: pointer;
         transition: background 0.2s, box-shadow 0.2s;
         box-shadow: 0 2px 8px rgba(78,156,255,0.08);
      }
      .btn:hover {
         background: linear-gradient(90deg, #38c172 0%, #4e9cff 100%);
         box-shadow: 0 4px 16px rgba(56,193,114,0.12);
      }
      .message {
         background: #f8f9fa;
         color: #333;
         border-left: 4px solid #4e9cff;
         padding: 0.8rem 1rem;
         border-radius: 6px;
         margin-bottom: 0.5rem;
         font-size: 0.98rem;
         box-shadow: 0 1px 4px rgba(0,0,0,0.04);
         animation: fadeIn 0.7s;
      }
      @keyframes fadeIn {
         from { opacity: 0; transform: translateY(-10px);}
         to { opacity: 1; transform: translateY(0);}
      }
      @media (max-width: 500px) {
         form {
            padding: 1.5rem 0.7rem;
            max-width: 98vw;
         }
      }
   </style>
</head>
<body style="background-image: url('images/kopi.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
<?php include '../components/admin_header.php' ?>

<section class="form-container">
   <form action="" method="POST" autocomplete="off">
      <h3><i class="fa-solid fa-user-shield"></i> Register New Admin</h3>
      <?php if(!empty($message)): ?>
         <?php foreach($message as $msg): ?>
            <div class="message"><?= htmlspecialchars($msg) ?></div>
         <?php endforeach; ?>
      <?php endif; ?>
      <input type="text" name="name" maxlength="20" required placeholder="Enter your username" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" maxlength="20" required placeholder="Enter your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="cpass" maxlength="20" required placeholder="Confirm your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="Register Now" name="submit" class="btn">
   </form>
</section>

<script src="../js/admin_script.js"></script>
</body>
</html>