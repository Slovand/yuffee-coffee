<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

$message = [];

if(isset($_POST['update_payment'])){
   $order_id = $_POST['order_id'];
   $payment_status = $_POST['payment_status'];
   $update_status = $conn->prepare("UPDATE `orders` SET payment_status = ? WHERE id = ?");
   $update_status->execute([$payment_status, $order_id]);
   $message[] = 'Payment status updated!';
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_order = $conn->prepare("DELETE FROM `orders` WHERE id = ?");
   $delete_order->execute([$delete_id]);
   $message[] = 'Order deleted!';
   header('location:placed_orders.php?msg=deleted');
   exit;
}

if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'){
   $message[] = 'Order deleted!';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Placed Orders</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
   <style>
      body {
         font-family: 'Segoe UI', Arial, sans-serif;
         background: linear-gradient(120deg, #f8fafc 0%, #e0e7ef 100%);
         margin: 0;
         min-height: 100vh;
      }
      .placed-orders {
         max-width: 1200px;
         margin: 40px auto;
         padding: 20px;
         background: #fff;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(60, 72, 88, 0.12);
      }
      .heading {
         text-align: center;
         font-size: 2.5rem;
         color: #2d3748;
         margin-bottom: 30px;
         letter-spacing: 2px;
         font-weight: 700;
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
         gap: 28px;
      }
      .box {
         background: #f9fafb;
         border-radius: 14px;
         box-shadow: 0 4px 16px rgba(60, 72, 88, 0.08);
         padding: 28px 22px 22px 22px;
         transition: box-shadow 0.2s;
         position: relative;
      }
      .box:hover {
         box-shadow: 0 8px 32px rgba(60, 72, 88, 0.16);
      }
      .box p {
         margin: 0 0 10px 0;
         color: #374151;
         font-size: 1.05rem;
      }
      .box span {
         color: #2563eb;
         font-weight: 600;
      }
      .drop-down {
         width: 100%;
         padding: 8px 10px;
         border-radius: 6px;
         border: 1px solid #cbd5e1;
         margin-bottom: 12px;
         font-size: 1rem;
         background: #fff;
         color: #374151;
         outline: none;
         transition: border 0.2s;
      }
      .drop-down:focus {
         border: 1.5px solid #2563eb;
      }
      .flex-btn {
         display: flex;
         gap: 10px;
         margin-top: 8px;
      }
      .btn, .delete-btn {
         padding: 8px 18px;
         border: none;
         border-radius: 6px;
         font-size: 1rem;
         cursor: pointer;
         transition: background 0.2s, color 0.2s;
         font-weight: 600;
         text-decoration: none;
         display: inline-block;
      }
      .btn {
         background: #2563eb;
         color: #fff;
      }
      .btn:hover {
         background: #1e40af;
      }
      .delete-btn {
         background: #f87171;
         color: #fff;
      }
      .delete-btn:hover {
         background: #dc2626;
      }
      .empty {
         text-align: center;
         color: #64748b;
         font-size: 1.2rem;
         margin-top: 40px;
      }
      .status-badge {
         display: inline-block;
         padding: 2px 12px;
         border-radius: 12px;
         font-size: 0.95rem;
         font-weight: 600;
         margin-left: 6px;
      }
      .status-pending {
         background: #fef3c7;
         color: #b45309;
      }
      .status-completed {
         background: #d1fae5;
         color: #047857;
      }
      .messages {
         max-width: 600px;
         margin: 0 auto 24px auto;
         padding: 0;
         list-style: none;
      }
      .messages li {
         background: #e0f2fe;
         color: #0369a1;
         border-left: 5px solid #2563eb;
         padding: 12px 18px;
         border-radius: 8px;
         margin-bottom: 10px;
         font-size: 1.08rem;
         box-shadow: 0 2px 8px rgba(60, 72, 88, 0.06);
      }
      @media (max-width: 600px) {
         .placed-orders {
            padding: 8px;
         }
         .box {
            padding: 16px 8px 12px 8px;
         }
      }
   </style>
</head>
<body style="background-image: url('images/kopi.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php include '../components/admin_header.php' ?>

<section class="placed-orders">

   <h1 class="heading"><span>Placed Orders</span></h1>

   <?php if(!empty($message)): ?>
      <ul class="messages">
         <?php foreach($message as $msg): ?>
            <li><?= htmlspecialchars($msg) ?></li>
         <?php endforeach; ?>
      </ul>
   <?php endif; ?>

   <div class="box-container">

   <?php
      $select_orders = $conn->prepare("SELECT * FROM `orders` ORDER BY placed_on DESC");
      $select_orders->execute();
      if($select_orders->rowCount() > 0){
         while($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="box">
      <p><i class="fa-solid fa-user"></i> <span><?= htmlspecialchars($fetch_orders['name']); ?></span></p>
      <p><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($fetch_orders['email']); ?></p>
      <p><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($fetch_orders['number']); ?></p>
      <p><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($fetch_orders['address']); ?></p>
      <p><i class="fa-solid fa-calendar"></i> <?= htmlspecialchars($fetch_orders['placed_on']); ?></p>
      <p><i class="fa-solid fa-box"></i> Products: <span><?= htmlspecialchars($fetch_orders['total_products']); ?></span></p>
      <p><i class="fa-solid fa-money-bill-wave"></i> Total: <span>Rp<?= htmlspecialchars($fetch_orders['total_price']); ?>,-</span></p>
      <p><i class="fa-solid fa-credit-card"></i> Method: <span><?= htmlspecialchars($fetch_orders['method']); ?></span></p>
      <p>
         <i class="fa-solid fa-receipt"></i> Payment:
         <?php if($fetch_orders['payment_status'] == 'completed'): ?>
            <span class="status-badge status-completed">Completed</span>
         <?php else: ?>
            <span class="status-badge status-pending">Pending</span>
         <?php endif; ?>
      </p>
      <form action="" method="POST" autocomplete="off">
         <input type="hidden" name="order_id" value="<?= $fetch_orders['id']; ?>">
         <select name="payment_status" class="drop-down" required>
            <option value="" disabled selected>Change status</option>
            <option value="pending" <?= $fetch_orders['payment_status']=='pending'?'selected':''; ?>>Pending</option>
            <option value="completed" <?= $fetch_orders['payment_status']=='completed'?'selected':''; ?>>Completed</option>
         </select>
         <div class="flex-btn">
            <input type="submit" value="Update" class="btn" name="update_payment">
            <a href="placed_orders.php?delete=<?= $fetch_orders['id']; ?>" class="delete-btn" onclick="return confirm('Delete this order?');">Delete</a>
         </div>
      </form>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">No orders placed yet!</p>';
   }
   ?>

   </div>

</section>

<script src="../js/admin_script.js"></script>
</body>
</html>