<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

// Fetch admin profile
$fetch_profile = [];
$select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
$select_profile->execute([$admin_id]);
if($select_profile->rowCount() > 0){
   $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">

   <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">

   <!-- Font Awesome CDN -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS -->
   <link rel="stylesheet" href="../css/admin_style.css">

   <style>
      body {
         font-family: 'Montserrat', Arial, sans-serif;
         background: url('images/coffee-bg.jpg') center center/cover no-repeat fixed;
         margin: 0;
         min-height: 100vh;
         position: relative;
      }
      body::before {
         content: "";
         position: fixed;
         top: 0; left: 0; right: 0; bottom: 0;
         background: rgba(34, 40, 49, 0.85);
         z-index: 0;
      }
      .dashboard {
         position: relative;
         z-index: 1;
         max-width: 1200px;
         margin: 40px auto 0 auto;
         padding: 30px 20px;
         background: rgba(255,255,255,0.10);
         border-radius: 18px;
         box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
         backdrop-filter: blur(6px);
      }
      .dashboard .heading {
         color: #fff;
         text-align: center;
         font-size: 2.5rem;
         font-weight: 600;
         margin-bottom: 35px;
         letter-spacing: 1px;
         text-shadow: 0 2px 8px rgba(0,0,0,0.2);
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
         gap: 28px;
      }
      .box {
         background: rgba(255,255,255,0.92);
         border-radius: 16px;
         box-shadow: 0 4px 24px rgba(0,0,0,0.08);
         padding: 32px 24px 28px 24px;
         display: flex;
         flex-direction: column;
         align-items: center;
         transition: transform 0.18s, box-shadow 0.18s;
         position: relative;
      }
      .box:hover {
         transform: translateY(-6px) scale(1.025);
         box-shadow: 0 8px 32px rgba(31, 38, 135, 0.18);
      }
      .box h3 {
         font-size: 2.1rem;
         color: #222831;
         margin: 0 0 10px 0;
         font-weight: 600;
         letter-spacing: 1px;
      }
      .box p {
         font-size: 1.1rem;
         color: #393e46;
         margin-bottom: 18px;
         text-align: center;
      }
      .btn {
         display: inline-block;
         padding: 10px 26px;
         background: linear-gradient(90deg, #00adb5 0%, #393e46 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         font-size: 1rem;
         font-weight: 600;
         text-decoration: none;
         transition: background 0.18s, box-shadow 0.18s;
         box-shadow: 0 2px 8px rgba(0,0,0,0.08);
         cursor: pointer;
      }
      .btn:hover {
         background: linear-gradient(90deg, #393e46 0%, #00adb5 100%);
         box-shadow: 0 4px 16px rgba(0,0,0,0.12);
      }
      @media (max-width: 700px) {
         .dashboard {
            padding: 18px 5px;
         }
         .box-container {
            gap: 16px;
         }
         .box {
            padding: 22px 10px 18px 10px;
         }
      }
   </style>
</head>
<body style="background-image: url('images/coffee-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php include '../components/admin_header.php' ?>

<section class="dashboard">

   <h1 class="heading"><i class="fas fa-tachometer-alt"></i> Dashboard</h1>

   <div class="box-container">

      <div class="box">
         <h3>Welcome!</h3>
         <p><?= htmlspecialchars($fetch_profile['name'] ?? 'Admin'); ?></p>
         <a href="update_profile.php" class="btn"><i class="fas fa-user-edit"></i> Update Profile</a>
      </div>

      <div class="box">
         <?php
            $total_pendings = 0;
            $select_pendings = $conn->prepare("SELECT total_price FROM `orders` WHERE payment_status = ?");
            $select_pendings->execute(['pending']);
            while($fetch_pendings = $select_pendings->fetch(PDO::FETCH_ASSOC)){
               $total_pendings += $fetch_pendings['total_price'];
            }
         ?>
         <h3><span>Rp</span><?= number_format($total_pendings,0,',','.'); ?><span>,-</span></h3>
         <p>Total Pendings</p>
         <a href="placed_orders.php" class="btn"><i class="fas fa-clock"></i> See Orders</a>
      </div>

      <div class="box">
         <?php
            $total_completes = 0;
            $select_completes = $conn->prepare("SELECT total_price FROM `orders` WHERE payment_status = ?");
            $select_completes->execute(['completed']);
            while($fetch_completes = $select_completes->fetch(PDO::FETCH_ASSOC)){
               $total_completes += $fetch_completes['total_price'];
            }
         ?>
         <h3><span>Rp</span><?= number_format($total_completes,0,',','.'); ?><span>,-</span></h3>
         <p>Total Completes</p>
         <a href="placed_orders.php" class="btn"><i class="fas fa-check-circle"></i> See Orders</a>
      </div>

      <div class="box">
         <?php
            $select_orders = $conn->prepare("SELECT * FROM `orders`");
            $select_orders->execute();
            $numbers_of_orders = $select_orders->rowCount();
         ?>
         <h3><?= $numbers_of_orders; ?></h3>
         <p>Total Orders</p>
         <a href="placed_orders.php" class="btn"><i class="fas fa-list"></i> See Orders</a>
      </div>

      <div class="box">
         <?php
            $select_products = $conn->prepare("SELECT * FROM `products`");
            $select_products->execute();
            $numbers_of_products = $select_products->rowCount();
         ?>
         <h3><?= $numbers_of_products; ?></h3>
         <p>Products Added</p>
         <a href="products.php" class="btn"><i class="fas fa-box"></i> See Products</a>
      </div>

      <div class="box">
         <?php
            $select_users = $conn->prepare("SELECT * FROM `users`");
            $select_users->execute();
            $numbers_of_users = $select_users->rowCount();
         ?>
         <h3><?= $numbers_of_users; ?></h3>
         <p>Users Accounts</p>
         <a href="users_accounts.php" class="btn"><i class="fas fa-users"></i> See Users</a>
      </div>

      <div class="box">
         <?php
            $select_admins = $conn->prepare("SELECT * FROM `admin`");
            $select_admins->execute();
            $numbers_of_admins = $select_admins->rowCount();
         ?>
         <h3><?= $numbers_of_admins; ?></h3>
         <p>Admins</p>
         <a href="admin_accounts.php" class="btn"><i class="fas fa-user-shield"></i> See Admins</a>
      </div>

      <div class="box">
         <?php
            $select_messages = $conn->prepare("SELECT * FROM `messages`");
            $select_messages->execute();
            $numbers_of_messages = $select_messages->rowCount();
         ?>
         <h3><?= $numbers_of_messages; ?></h3>
         <p>New Messages</p>
         <a href="messages.php" class="btn"><i class="fas fa-envelope"></i> See Messages</a>
      </div>

   </div>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>