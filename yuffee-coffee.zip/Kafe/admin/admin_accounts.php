<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
   exit;
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_admin = $conn->prepare("DELETE FROM `admin` WHERE id = ?");
   $delete_admin->execute([$delete_id]);
   header('location:admin_accounts.php');
   exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admins Accounts</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">

   <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

   <!-- Font Awesome CDN -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS -->
   <link rel="stylesheet" href="../css/admin_style.css">

   <style>
      body {
         font-family: 'Inter', Arial, sans-serif;
         background: linear-gradient(rgba(30,30,30,0.7), rgba(30,30,30,0.7)), url('images/2016_09_29_12990_1475116504._large.jpg') center/cover no-repeat;
         min-height: 100vh;
         margin: 0;
         color: #222;
      }
      .accounts {
         max-width: 900px;
         margin: 40px auto 0 auto;
         padding: 30px 20px;
         background: rgba(255,255,255,0.95);
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(0,0,0,0.18);
      }
      .accounts .heading {
         text-align: center;
         font-size: 2.2rem;
         font-weight: 600;
         margin-bottom: 30px;
         color: #2d3748;
         letter-spacing: 1px;
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
         gap: 24px;
      }
      .box {
         background: rgba(245, 245, 245, 0.95);
         border-radius: 14px;
         box-shadow: 0 4px 16px rgba(0,0,0,0.07);
         padding: 24px 20px 18px 20px;
         display: flex;
         flex-direction: column;
         align-items: flex-start;
         transition: box-shadow 0.2s;
         position: relative;
      }
      .box:hover {
         box-shadow: 0 8px 32px rgba(0,0,0,0.13);
      }
      .box p {
         margin: 0 0 10px 0;
         font-size: 1.05rem;
         color: #444;
      }
      .box p span {
         font-weight: 600;
         color: #2563eb;
      }
      .flex-btn {
         display: flex;
         gap: 10px;
         margin-top: 10px;
      }
      .option-btn, .delete-btn {
         padding: 8px 18px;
         border: none;
         border-radius: 6px;
         font-size: 1rem;
         font-weight: 500;
         cursor: pointer;
         text-decoration: none;
         transition: background 0.18s, color 0.18s, box-shadow 0.18s;
         box-shadow: 0 2px 8px rgba(0,0,0,0.04);
      }
      .option-btn {
         background: #2563eb;
         color: #fff;
      }
      .option-btn:hover {
         background: #1e40af;
      }
      .delete-btn {
         background: #f87171;
         color: #fff;
      }
      .delete-btn:hover {
         background: #b91c1c;
      }
      .empty {
         grid-column: 1/-1;
         text-align: center;
         color: #888;
         font-size: 1.1rem;
         margin-top: 20px;
      }
      @media (max-width: 600px) {
         .accounts {
            padding: 12px 4px;
         }
         .accounts .heading {
            font-size: 1.3rem;
         }
         .box {
            padding: 14px 8px 12px 8px;
         }
      }
   </style>
</head>
<body 
<body style="background-image: url('images/kopi.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php include '../components/admin_header.php' ?>

<section class="accounts">

   <h1 class="heading"><i class="fa-solid fa-user-shield"></i> Admins Account</h1>

   <div class="box-container">

      <div class="box" style="background: linear-gradient(90deg, #2563eb 60%, #60a5fa 100%); color: #fff;">
         <p style="font-weight:600;">Register new admin</p>
         <a href="register_admin.php" class="option-btn" style="background:#fff; color:#2563eb; font-weight:600;">Register</a>
      </div>

      <?php
         $select_account = $conn->prepare("SELECT * FROM `admin`");
         $select_account->execute();
         if($select_account->rowCount() > 0){
            while($fetch_accounts = $select_account->fetch(PDO::FETCH_ASSOC)){  
      ?>
      <div class="box">
         <p><i class="fa-solid fa-id-badge"></i> Admin ID: <span><?= htmlspecialchars($fetch_accounts['id']); ?></span></p>
         <p><i class="fa-solid fa-user"></i> Username: <span><?= htmlspecialchars($fetch_accounts['name']); ?></span></p>
         <div class="flex-btn">
            <a href="admin_accounts.php?delete=<?= $fetch_accounts['id']; ?>" class="delete-btn" onclick="return confirm('Delete this account?');"><i class="fa-solid fa-trash"></i> Delete</a>
            <?php
               if($fetch_accounts['id'] == $admin_id){
                  echo '<a href="update_profile.php" class="option-btn"><i class="fa-solid fa-pen-to-square"></i> Update</a>';
               }
            ?>
         </div>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">No accounts available</p>';
      }
      ?>

   </div>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>