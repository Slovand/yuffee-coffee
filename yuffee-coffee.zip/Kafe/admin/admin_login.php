<?php
include '../components/connect.php';
session_start();

if(isset($_SESSION['admin_id'])){
   header('location:dashboard.php');
   exit;
}

if(isset($_POST['submit'])){
   $name = trim($_POST['name']);
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $password = $_POST['password'];

   $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE name = ?");
   $select_admin->execute([$name]);
   $row = $select_admin->fetch(PDO::FETCH_ASSOC);

   if($row && sha1($password) === $row['password']){
      $_SESSION['admin_id'] = $row['id'];
      header('location:dashboard.php');
      exit;
   } else {
      $message[] = 'incorrect username or password!';
   }
}
?>

<!-- Bagian HTML tetap sama -->

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin login</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body  style="background-image: url('images/coffee-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<!-- admin login form section starts  -->

<section class="form-container" style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); border-radius: 15px; padding: 20px; width: 300px; margin: auto; text-align: center;">

   <form action="" method="POST">
      <h3 style="color: #000000;">login now</h3>
      <input type="text" name="name" maxlength="20" required placeholder="enter your username" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="password" maxlength="20" required placeholder="enter your password" class="box" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="login now" name="submit" class="btn" style="background-color: #4CAF50; color: #fff; border: none; padding: 10px 15px; cursor: pointer;">
      <a href="../home.php" style="position: fixed; top: 20px; left: 20px; background: #4CAF50; color: #fff; padding: 8px 14px; border-radius: 5px; text-decoration: none; z-index: 1000;">
         <i class="fas fa-arrow-left"></i> Back
      </a>
   </form>

</section>


<!-- admin login form section ends -->











</body>
</html>