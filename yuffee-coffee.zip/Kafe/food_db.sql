-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Jun 2025 pada 05.26
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(2, 'Jagoan', '3acd0be86de7dcccdbf91b20f94a68cea535922d'),
(6, 'owi', '30e3bd867cee3a788c0d788be79abb3ab305eb1f');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `pid`, `name`, `price`, `quantity`, `image`) VALUES
(9, 1, 5, 'roti', 30000, 3, 'coffee-beans-bg.jpg'),
(14, 10, 5, 'roti', 30000, 1, 'coffee-beans-bg.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `messages`
--

CREATE TABLE `messages` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(1, 0, 'Jagoan', 'hhhh2@h.com', '1122334455', 'Asu koe');

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `number` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` date NOT NULL DEFAULT current_timestamp(),
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(1, 1, 'Fajar Irham Hakim', '0987654321', 'fajarirhamh18@gmail.com', 'paypal', '123132, 1321, 13123, 1321, 13213, 1312, 21312 - 213', 'Burger (7000 x 1)', 7000, '2025-06-08', 'completed'),
(2, 1, 'Fajar Irham Hakim', '0987654321', 'fajarirhamh18@gmail.com', 'paytm', '123132, 1321, 13123, 1321, 13213, 1312, 21312 - 213', 'pizza (10000 x 3) - Burger (7000 x 2)', 44000, '2025-06-08', 'completed'),
(3, 1, 'Fajar Irham Hakim', '0987654321', 'fajarirhamh18@gmail.com', 'cash on delivery', '123132, 1321, 13123, 1321, 13213, 1312, 21312 - 213', 'pizza (10000 x 2)', 20000, '2025-06-09', 'completed'),
(4, 1, 'Fajar Irham Hakim', '0987654321', 'fajarirhamh18@gmail.com', 'paytm', '123132, 1321, 13123, 1321, 13213, 1312, 21312 - 213', 'Minum (12000 x 1) - Burger (7000 x 1) - pizza (10000 x 1)', 29000, '2025-06-10', 'completed'),
(5, 1, 'Fajar Irham Hakim', '0987654321', 'fajarirhamh18@gmail.com', 'cash on delivery', '123132, 1321, 13123, 1321, 13213, 1312, 21312 - 213', 'Minum (12000 x 1)', 12000, '2025-06-10', 'pending'),
(6, 10, 'haphap', '7878787878', 'haphap@gmail.com', 'credit card', 'Flat/No: 1212, Gedung: 123, Area: ff, Kecamatan: dd, Kota: aa, Provinsi: ewq, Negara: wq, Kode Pos: 1232', 'roti (30000 x 1) - Burger (7000 x 1) - Minum (12000 x 2) - pizza (10000 x 1)', 71000, '2025-06-11', 'pending');

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `image`) VALUES
(1, 'Burger', 'fast food', 7000, 'home-img-2.png'),
(2, 'pizza', 'fast food', 10000, 'home-img-1.png'),
(3, 'Minum', 'drinks', 12000, 'cream-coffee.jpg'),
(4, 'bakery', 'desserts', 25000, 'bakery.jpg'),
(5, 'roti', 'main dish', 30000, 'coffee-beans-bg.jpg'),
(6, 'Americano', 'drinks', 20000, 'black-coffee.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `number`, `password`, `address`) VALUES
(1, 'Fajar Irham Hakim', 'fajarirhamh18@gmail.com', '0987654321', '601f1889667efaebb33b8c12572835da3f027f78', '123132, 1321, 13123, 1321, 13213, 1312, 21312 - 213'),
(2, 'Subhan', 'Subhan@m.com', '1122334411', '123456', ''),
(3, 'JARWO', 'Jarwo@gmail.com', '0989089082', '$2y$10$BhBhYnIkawjNMacxpdqarO7qJaPLKpwGYlPh1pqtpiT', ''),
(4, 'Andreas', 'Andreas@g.com', '1234567899', '$2y$10$6GVa0SxnJlG9YY9LItlOvOx9PQRBI5LQ5SBVzT36d9V', ''),
(5, 'joan', 'joan@gmail.com', '1111111111', '$2y$10$STmexXZJVUV2ZofY1u1GDuIAZ4HFqGX8ly.QTMSFQSg', ''),
(6, 'kk', 'kk@gmail.com', '2222222222', '$2y$10$sNIyKA6ivoMEi0HtUY28puRNIO5pfwMAWad9LGB4v8z', ''),
(7, 'll', 'lamin@gmail.com', '2121212121', '$2y$10$lWUU6iVpW/hyciO2TfIcVeg5aZrwxIiSzsh.XaFPNer', ''),
(8, 'hopa', 'tifositifamiglia@gmail.com', '7777777777', '$2y$10$09UpUqw22Wm6oj7agp125uOIF5cKeQ61g42wMRYsdsz', ''),
(9, 'gelo', 'gelo@gmail.com', '7676767676', '277c4593fcbf163754e91d6cb8676a8abc96f5e4', ''),
(10, 'haphap', 'haphap@gmail.com', '7878787878', '279ad49defd3670b4faf4a67c32f62f65bc011db', 'Flat/No: 1212, Gedung: 123, Area: ff, Kecamatan: dd, Kota: aa, Provinsi: ewq, Negara: wq, Kode Pos: 1232');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
