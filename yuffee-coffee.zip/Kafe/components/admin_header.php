<?php
// Pastikan $message didefinisikan sebelum digunakan, meskipun biasanya sudah ada dari script yang meng-include ini
if (isset($message)) {
    foreach ($message as $msg) {
        // Asumsi $msg adalah array dengan 'type' dan 'text' seperti di update_product.php
        $msg_type = $msg['type'] ?? 'info'; // Default type if not set
        $msg_text = $msg['text'] ?? ''; // Default text if not set
        echo '
        <div class="message ' . htmlspecialchars($msg_type) . '">
            <span>' . htmlspecialchars($msg_text) . '</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
        </div>
        ';
    }
}
?>

<style>
/* CSS Anda yang sudah ada */
:root {
    --primary: #ff9800;
    --dark: #181818;
    --light: #fff;
    --gray: #f5f5f5;
    --accent: #333;
    --danger: #e53935;
    --shadow: 0 4px 24px rgba(0,0,0,0.08);
    --radius: 12px;
    --transition: 0.2s cubic-bezier(.4,0,.2,1);
}

body {
    background: var(--gray);
    font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.header {
    background: var(--dark);
    color: var(--light);
    padding: 0;
    box-shadow: var(--shadow);
    position: sticky;
    top: 0;
    z-index: 100;
}

.header .flex {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    padding: 18px 32px;
}

.header .logo {
    font-size: 2.2rem;
    color: var(--light);
    font-weight: 700;
    text-decoration: none;
    letter-spacing: 1px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.header .logo span {
    color: var(--primary);
    font-weight: 800;
}

.header img {
    border-radius: 50%;
    margin-left: 22px; /* Mungkin perlu disesuaikan atau dihapus jika konflik dengan flex */
    border: 3px solid var(--primary);
    box-shadow: 0 2px 8px rgba(0,0,0,0.10);
    background: var(--light);
}

.header .navbar {
    display: flex;
    gap: 22px;
}

.header .navbar a {
    color: var(--light);
    font-size: 1.08rem;
    text-decoration: none;
    font-weight: 500;
    padding: 6px 14px;
    border-radius: 6px;
    transition: background var(--transition), color var(--transition);
    letter-spacing: 0.5px;
}

.header .navbar a:hover, .header .navbar a.active {
    background: var(--primary);
    color: var(--dark);
}

.header .icons {
    display: flex;
    gap: 18px;
    font-size: 1.6rem;
    cursor: pointer;
    color: var(--primary);
    transition: color var(--transition);
}

.header .icons div:hover {
    color: var(--light);
}

.header .profile {
    background: var(--accent);
    padding: 22px 26px 18px 26px;
    border-radius: var(--radius);
    text-align: center;
    min-width: 200px;
    box-shadow: var(--shadow);
    margin-left: 30px;
    display: none; /* Default hidden, akan di-toggle dengan JS */
    flex-direction: column;
    align-items: center;
    position: absolute; /* Posisikan absolut agar tidak mengganggu layout utama */
    top: 100%; /* Di bawah header */
    right: 0;
    z-index: 99;
}

/* Tampilkan profile saat aktif (misal dengan JavaScript) */
.header .profile.active {
    display: flex;
}

.header .profile p {
    margin: 0 0 12px 0;
    font-weight: 700;
    color: var(--primary);
    font-size: 1.1rem;
    letter-spacing: 0.5px;
}

.header .btn, .header .option-btn, .header .delete-btn {
    display: inline-block;
    margin: 6px 0;
    padding: 8px 22px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 600;
    font-size: 1rem;
    transition: background var(--transition), color var(--transition), border var(--transition);
    border: none;
    outline: none;
    cursor: pointer;
}

.header .btn {
    background: var(--primary);
    color: var(--light);
    box-shadow: 0 2px 8px rgba(255,152,0,0.08);
}
.header .btn:hover {
    background: var(--light);
    color: var(--primary);
    border: 1.5px solid var(--primary);
}

.header .option-btn {
    background: #444;
    color: var(--light);
}
.header .option-btn:hover {
    background: var(--primary);
    color: var(--dark);
}

.header .delete-btn {
    background: var(--danger);
    color: var(--light);
    margin-top: 10px;
}
.header .delete-btn:hover {
    background: var(--light);
    color: var(--danger);
    border: 1.5px solid var(--danger);
}

.header .flex-btn {
    display: flex;
    gap: 10px;
    justify-content: center;
    margin: 8px 0;
}

/* Pesan notifikasi */
.message {
    background: var(--primary); /* Menggunakan warna primary default */
    color: var(--light);
    padding: 12px 24px;
    margin: 18px auto 0 auto;
    border-radius: var(--radius);
    max-width: 420px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 1.08rem;
    box-shadow: var(--shadow);
    animation: fadeIn 0.5s;
}

.message.success {
    background: #22c55e; /* Hijau */
    color: var(--light);
}
.message.error {
    background: #ef4444; /* Merah */
    color: var(--light);
}
.message.info {
    background: #3b82f6; /* Biru */
    color: var(--light);
}


@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px);}
    to { opacity: 1; transform: translateY(0);}
}

.message i {
    cursor: pointer;
    margin-left: 18px;
    font-size: 1.2rem;
    transition: color var(--transition);
}
.message i:hover {
    color: var(--dark);
}

@media (max-width: 900px) {
    .header .flex {
        flex-direction: column;
        align-items: stretch;
        padding: 14px 10px;
    }
    .header .navbar {
        justify-content: center;
        gap: 12px;
        margin: 10px 0;
    }
    .header .profile {
        margin-left: 0;
        margin-top: 12px;
        position: relative; /* Kembali ke posisi relatif di mobile */
        top: auto;
        right: auto;
        width: 100%; /* Penuhi lebar di mobile */
    }
    .header .icons {
        align-self: flex-end; /* Pindahkan ikon ke kanan atas */
        margin-top: -30px; /* Sesuaikan posisi vertikal */
        margin-right: 10px;
    }
}

@media (max-width: 600px) {
    .header .flex {
        padding: 8px 2vw;
    }
    .header .navbar {
        flex-wrap: wrap;
        gap: 8px;
    }
    .header .profile {
        padding: 14px 8px 10px 8px;
        min-width: 120px;
    }
    .header img {
        width: 40px;
        height: 40px;
        margin-left: 10px;
    }
    .header .logo {
        font-size: 1.8rem;
    }
}
</style>

<header class="header">
    <section class="flex">
        <div style="display: flex; align-items: center;">
            <a href="dashboard.php" class="logo">
                <img src="images/iconyuffee.png" width="48" height="48" alt="Admin Icon" style="margin-left:0; margin-right:10px;">
                Admin<span>Panel</span>
            </a>
        </div>
        <nav class="navbar">
            <a href="dashboard.php">Beranda</a>
            <a href="products.php">Produk</a>
            <a href="placed_orders.php">Pesanan</a>
            <a href="admin_accounts.php">Admin</a>
            <a href="users_accounts.php">Pengguna</a>
            <a href="messages.php">Pesan</a>
        </nav>
        <div class="icons">
            <div id="menu-btn" class="fas fa-bars" title="Menu"></div>
            <div id="user-btn" class="fas fa-user" title="Profil"></div>
        </div>
        <div class="profile">
            <?php
            // Pastikan $conn dan $admin_id ada sebelum melakukan query
            if (isset($conn) && isset($admin_id)) {
                $select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
                $select_profile->execute([$admin_id]);
                $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

                // Periksa apakah profil ditemukan dan kunci 'name' ada
                if ($fetch_profile && isset($fetch_profile['name'])) {
                    // Casting ke string untuk memastikan htmlspecialchars menerima tipe data yang benar
                    echo '<p>' . htmlspecialchars((string)$fetch_profile['name']) . '</p>';
                } else {
                    echo '<p>Admin</p>'; // Fallback jika tidak ada profil atau nama tidak ada
                }
            } else {
                echo '<p>Admin</p>'; // Fallback jika $conn atau $admin_id tidak disetel
            }
            ?>
            <a href="update_profile.php" class="btn">Perbarui Profil</a>
            <div class="flex-btn">
                <a href="admin_login.php" class="option-btn">Login</a>
                <a href="register_admin.php" class="option-btn">Daftar</a>
            </div>
            <a href="../components/admin_logout.php" onclick="return confirm('Yakin ingin keluar dari website ini?');" class="delete-btn">Logout</a>
        </div>
    </section>
</header>
<script>
    // JavaScript untuk mengelola tampilan menu dan profil
    let navbar = document.querySelector('.header .navbar');
    let profile = document.querySelector('.header .profile');

    document.querySelector('#menu-btn').onclick = () => {
        navbar.classList.toggle('active');
        profile.classList.remove('active'); // Tutup profil saat menu dibuka
    }

    document.querySelector('#user-btn').onclick = () => {
        profile.classList.toggle('active');
        navbar.classList.remove('active'); // Tutup menu saat profil dibuka
    }

    window.onscroll = () => {
        navbar.classList.remove('active');
        profile.classList.remove('active');
    }
</script>