<?php
// admin_logout.php

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Unset all session variables
$_SESSION = [];

// Destroy session data on the server
session_unset();
session_destroy();

// Remove session cookie if set
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Redirect to admin login page
$redirectUrl = '../admin/admin_login.php';
if (!headers_sent()) {
    header("Location: $redirectUrl");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logging Out...</title>
    <meta http-equiv="refresh" content="2;url=<?= htmlspecialchars($redirectUrl) ?>">
    <style>
        body {
            background: #f8fafc;
            color: #222;
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .logout-message {
            background: #fff;
            padding: 2rem 3rem;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            text-align: center;
        }
        .logout-message h1 {
            color: #2d6cdf;
            margin-bottom: 0.5em;
        }
        .logout-message p {
            color: #555;
        }
    </style>
</head>
<body>
    <div class="logout-message">
        <h1>Logging Out...</h1>
        <p>You have been securely logged out.<br>
        Redirecting to login page...</p>
    </div>
</body>
</html>