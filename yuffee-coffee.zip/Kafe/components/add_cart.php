<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {

   // Redirect if user is not logged in
   if (empty($user_id)) {
      header('Location: login.php');
      exit;
   }

   // Sanitize and validate input
   $pid   = filter_input(INPUT_POST, 'pid', FILTER_VALIDATE_INT);
   $name  = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
   $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
   $image = filter_input(INPUT_POST, 'image', FILTER_SANITIZE_URL);
   $qty   = filter_input(INPUT_POST, 'qty', FILTER_VALIDATE_INT);

   // Validate required fields
   if (!$pid || !$name || !$price || !$image || !$qty || $qty < 1) {
      $message[] = 'Invalid product data. Please try again.';
   } else {
      // Check if product is already in cart
      $stmt = $conn->prepare("SELECT 1 FROM `cart` WHERE pid = ? AND user_id = ?");
      $stmt->execute([$pid, $user_id]);

      if ($stmt->fetch()) {
         $message[] = 'Already added to cart!';
      } else {
         // Insert product into cart
         $insert = $conn->prepare(
            "INSERT INTO `cart` (user_id, pid, name, price, quantity, image) VALUES (?, ?, ?, ?, ?, ?)"
         );
         if ($insert->execute([$user_id, $pid, $name, $price, $qty, $image])) {
            $message[] = 'Added to cart!';
         } else {
            $message[] = 'Failed to add to cart. Please try again.';
         }
      }
   }
}
