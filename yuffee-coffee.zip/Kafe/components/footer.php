<footer class="footer">
   <section class="footer-grid">
      <div class="footer-box">
         <img src="/Kafe/images/email-icon.png" alt="Email Icon" class="footer-icon">
         <h3>Contact Email</h3>
         <a href="mailto:yuffeekafe@gmail.com">yuffeekafe@gmail.com</a>
      </div>
      <div class="footer-box">
         <img src="/Kafe/images/clock-icon.png" alt="Opening Hours Icon" class="footer-icon">
         <h3>Opening Hours</h3>
         <p>10:00 am – 11:00 pm</p>
      </div>
      <div class="footer-box">
         <img src="/Kafe/images/map-icon.png" alt="Location Icon" class="footer-icon">
         <h3>Our Address</h3>
         <a href="https://maps.app.goo.gl/your-location" target="_blank" rel="noopener">
            Jl. Raya Mr. Moch Ichsan No.91, Ngaliyan, Kec. Ngaliyan, Kota Semarang, Jawa Tengah 50181
         </a>
         <div class="footer-map">
            <iframe
               src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.937631529059!2d110.38417841477423!3d-7.001988494958808!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e708b006048b059%3A0xa8d26d8a5c91695b!2sYuffee%20Semarang!5e0!3m2!1sen!2sid!4v1686000000000!5m2!1sen!2sid"
               width="100%" height="160" style="border:0; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.10);"
               allowfullscreen="" loading="lazy"
               referrerpolicy="no-referrer-when-downgrade">
            </iframe>
         </div>
      </div>
      <div class="footer-box">
         <img src="/Kafe/images/phone-icon.png" alt="Phone Icon" class="footer-icon">
         <h3>Phone Number</h3>
         <a href="tel:081346162121">0812-8814-0162</a>
      </div>
   </section>
   <div class="footer-credit">
      &copy; <?php echo date('Y'); ?> <span>The Outer Clove Restaurant</span>
      <br>
      <small>Designed with <span style="color:#e63946;">&#10084;</span> in Semarang</small>
   </div>
</footer>

<div class="loader">
   <img src="/Kafe/images/loader.gif" alt="Loading...">
</div>

<style>
.footer {
   background: linear-gradient(120deg, #7ca982 0%, #a3b18a 100%);
   color:rgb(255, 255, 255);
   padding: 48px 0 24px 0;
   font-family: 'Segoe UI', Arial, sans-serif;
   box-shadow: 0 4px 24px rgba(255, 255, 255, 0.1);
   position: relative;
   z-index: 1;
}
.footer-grid {
   display: flex;
   flex-wrap: wrap;
   justify-content: center;
   gap: 36px;
   max-width: 1200px;
   margin: 0 auto 28px auto;
}
.footer-box {
   background: rgba(255, 255, 255, 0.1);
   border-radius: 18px;
   padding: 28px 22px 22px 22px;
   min-width: 220px;
   max-width: 300px;
   flex: 1 1 220px;
   text-align: center;
   box-shadow: 0 4px 16px rgba(255, 255, 255, 0.06);
   transition: transform 0.22s cubic-bezier(.4,2,.6,1), box-shadow 0.22s;
   border: 1.5px solid rgba(255, 255, 255, 0.13);
   backdrop-filter: blur(2px);
}
.footer-box:hover {
   transform: translateY(-8px) scale(1.04);
   background: rgba(255, 255, 255, 0.18);
   box-shadow: 0 8px 24px rgba(255, 255, 255, 0.13);
}
.footer-icon {
   width: 54px;
   height: 54px;
   margin-bottom: 14px;
   filter: drop-shadow(0 2px 6px rgba(163,177,138,0.18));
}
.footer-box h3 {
   margin: 12px 0 10px 0;
   font-size: 1.18rem;
   color:rgb(255, 255, 255);
   letter-spacing: 1.2px;
   font-weight: 600;
}
.footer-box a, .footer-box p {
   color:rgb(255, 255, 255);
   text-decoration: none;
   font-size: 1.04rem;
   word-break: break-word;
   transition: color 0.18s;
}
.footer-box a:hover {
   text-decoration: underline;
   color:rgb(255, 255, 255);
}
.footer-map {
   margin-top: 12px;
   border-radius: 12px;
   overflow: hidden;
   box-shadow: 0 2px 12px rgba(255, 255, 255, 0.1);
}
.footer-credit {
   text-align: center;
   font-size: 1.04rem;
   color:rgb(255, 255, 255);
   margin-top: 22px;
   letter-spacing: 1.1px;
   line-height: 1.7;
}
.footer-credit span {
   color:rgb(255, 255, 255);
   font-weight: bold;
   letter-spacing: 1.2px;
}
@media (max-width: 900px) {
   .footer-grid {
      flex-direction: column;
      align-items: center;
      gap: 24px;
   }
   .footer-box {
      max-width: 94vw;
   }
}
@media (max-width: 600px) {
   .footer {
      padding: 32px 0 16px 0;
   }
   .footer-box {
      padding: 18px 10px 14px 10px;
      min-width: 0;
   }
   .footer-credit {
      font-size: 0.98rem;
   }
}
</style>
