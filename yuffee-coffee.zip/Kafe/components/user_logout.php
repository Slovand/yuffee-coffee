<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_unset();
session_destroy();

// Absolute URL for redirection (adjust as needed)
$redirectUrl = '/Kafe/home.php';

// Redirect to home page if headers not sent
if (!headers_sent()) {
    header("Location: $redirectUrl");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logged Out</title>
    <style>
        body {
            background: #f8fafc;
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .logout-container {
            background: #fff;
            padding: 2.5rem 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            text-align: center;
        }
        .logout-container h1 {
            color: #2d3748;
            margin-bottom: 1rem;
        }
        .logout-container p {
            color: #4a5568;
            margin-bottom: 1.5rem;
        }
        .logout-container a {
            display: inline-block;
            padding: 0.5rem 1.5rem;
            background: #3182ce;
            color: #fff;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.2s;
        }
        .logout-container a:hover {
            background: #2563eb;
        }
    </style>
</head>
<body>
    <div class="logout-container">
        <h1>You have been logged out</h1>
        <p>Thank you for visiting. You have been successfully logged out.</p>
        <a href="<?php echo htmlspecialchars($redirectUrl); ?>">Return to Home</a>
    </div>
</body>
</html>