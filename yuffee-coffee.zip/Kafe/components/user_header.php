<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
   session_start();
}

// Get user ID from session
$user_id = $_SESSION['user_id'] ?? null;

// Display messages if set
if (!empty($message) && is_array($message)) {
   foreach ($message as $msg) {
      echo '<div class="message">';
      echo '<span>' . htmlspecialchars($msg) . '</span>';
      echo '<i class="fas fa-times" onclick="this.parentElement.remove();"></i>';
      echo '</div>';
   }
}
?>

<header class="header" style="background: linear-gradient(to right, rgb(112, 139, 96), #A3B18A);">
   <section class="flex">
      <a href="home.php" class="logo">
         <img src="images/iconyuffee.png" alt="Yuffee Logo" width="80" height="80">
      </a>

      <nav class="navbar">
         <a href="home.php">home</a>
         <a href="about.php">about</a>
         <a href="menu.php">menu</a>
         <a href="orders.php">orders</a>
         <a href="contact.php">contact</a>
         <a href="admin/admin_login.php">admin portal</a>
      </nav>

      <div class="icons">
         <?php
         // Count cart items for the user
         $total_cart_items = 0;
         if ($user_id && isset($conn)) {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM `cart` WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $total_cart_items = (int)$stmt->fetchColumn();
         }
         ?>
         <a href="search.php"><i class="fas fa-search"></i></a>
         <a href="cart.php"><i class="fas fa-shopping-cart"></i><span>(<?= $total_cart_items; ?>)</span></a>
         <div id="user-btn" class="fas fa-user"></div>
         <div id="menu-btn" class="fas fa-bars"></div>
      </div>

      <div class="profile">
         <?php
         if ($user_id && isset($conn)) {
            $stmt = $conn->prepare("SELECT name FROM `users` WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
               ?>
               <p class="name"><?= htmlspecialchars($user['name']); ?></p>
               <div class="flex">
                  <a href="profile.php" class="btn">profile</a>
                  <a href="components/user_logout.php" onclick="return confirm('logout from this website?');" class="delete-btn">logout</a>
               </div>
               <?php
            } else {
               ?>
               <p class="name">please login first!</p>
               <a href="login.php" class="btn">login</a>
               <?php
            }
         } else {
            ?>
            <p class="name">please login first!</p>
            <a href="login.php" class="btn">login</a>
            <?php
         }
         ?>
         <p class="account">
            <a href="login.php">login</a> or
            <a href="register.php">register</a>
         </p>
      </div>
   </section>
</header>
