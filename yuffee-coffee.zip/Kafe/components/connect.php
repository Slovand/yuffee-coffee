<?php

// Database configuration
$host     = 'localhost';
$db       = 'food_db';
$user     = 'root';
$pass     = '';
$charset  = 'utf8mb4';

// Data Source Name
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// PDO options for robust error handling and performance
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create PDO instance
    $conn = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // Log error and show generic message
    error_log('Database connection failed: ' . $e->getMessage());
    die('<div style="font-family:sans-serif;color:#b71c1c;background:#fff3f3;padding:20px;border-radius:8px;max-width:400px;margin:40px auto;text-align:center;">
            <h2 style="margin:0 0 10px 0;">Connection Error</h2>
            <p>Sorry, we are unable to connect to the database at the moment.</p>
        </div>');
}