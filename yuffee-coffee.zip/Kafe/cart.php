<?php
include 'components/connect.php';
session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   header('location:home.php');
   exit;
}

$message = [];

if(isset($_POST['delete'])){
   $cart_id = $_POST['cart_id'];
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
   $delete_cart_item->execute([$cart_id]);
   $message[] = 'Cart item deleted!';
}

if(isset($_POST['delete_all'])){
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart_item->execute([$user_id]);
   $message[] = 'Deleted all from cart!';
}

if(isset($_POST['update_qty'])){
   $cart_id = $_POST['cart_id'];
   $qty = filter_var($_POST['qty'], FILTER_VALIDATE_INT, [
      'options' => ['min_range' => 1, 'max_range' => 99]
   ]);
   if($qty !== false){
      $update_qty = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
      $update_qty->execute([$qty, $cart_id]);
      $message[] = 'Cart quantity updated';
   } else {
      $message[] = 'Invalid quantity!';
   }
}

$grand_total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Cart</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
   <style>
      body {
         font-family: 'Inter', Arial, sans-serif;
         background: #f7f8fa;
         color: #222;
         margin: 0;
         padding: 0;
      }
      .heading {
         background: linear-gradient(90deg, #27ae60 0%, #219150 100%);
         color: #fff;
         padding: 40px 0 30px 0;
         text-align: center;
         margin-bottom: 30px;
         box-shadow: 0 2px 8px rgba(39,174,96,0.08);
      }
      .heading h3 {
         font-size: 2.2em;
         font-weight: 700;
         margin: 0 0 10px 0;
         letter-spacing: 1px;
      }
      .heading p {
         font-size: 1.1em;
         margin: 0;
         color: #e0ffe0;
      }
      .heading a {
         color: #fff;
         text-decoration: underline;
      }
      .message {
         position: fixed;
         top: 30px;
         right: 30px;
         z-index: 9999;
         background: #27ae60;
         color: #fff;
         padding: 16px 32px;
         border-radius: 8px;
         box-shadow: 0 4px 24px rgba(39,174,96,0.13);
         font-size: 1.1em;
         animation: fadeIn 0.7s;
      }
      @keyframes fadeIn {
         from { opacity: 0; transform: translateY(-20px);}
         to { opacity: 1; transform: translateY(0);}
      }
      .products {
         max-width: 1100px;
         margin: 0 auto 40px auto;
         padding: 0 20px;
      }
      .products .title {
         font-size: 2em;
         font-weight: 700;
         margin-bottom: 30px;
         text-align: center;
         color: #27ae60;
         letter-spacing: 1px;
      }
      .box-container {
         display: flex;
         flex-wrap: wrap;
         gap: 32px;
         justify-content: center;
      }
      .box {
         background: #fff;
         border-radius: 16px;
         box-shadow: 0 4px 24px rgba(39,174,96,0.07);
         padding: 28px 24px 20px 24px;
         width: 340px;
         position: relative;
         transition: box-shadow 0.2s, transform 0.2s;
         display: flex;
         flex-direction: column;
         align-items: center;
      }
      .box:hover {
         box-shadow: 0 8px 32px rgba(39,174,96,0.13);
         transform: translateY(-4px) scale(1.01);
      }
      .box img {
         width: 100%;
         height: 180px;
         object-fit: cover;
         border-radius: 10px;
         margin-bottom: 18px;
         box-shadow: 0 2px 8px rgba(39,174,96,0.07);
         background: #f2f2f2;
      }
      .box .name {
         font-size: 1.18em;
         font-weight: 600;
         margin-bottom: 10px;
         color: #222;
         text-align: center;
         min-height: 48px;
         line-height: 1.3;
      }
      .box .flex {
         display: flex;
         align-items: center;
         gap: 12px;
         margin-bottom: 10px;
         width: 100%;
         justify-content: center;
      }
      .box .price {
         color: #27ae60;
         font-size: 1.1em;
         font-weight: bold;
         letter-spacing: 0.5px;
      }
      .box .qty {
         width: 54px;
         padding: 7px;
         border-radius: 6px;
         border: 1px solid #e0e0e0;
         text-align: center;
         font-size: 1em;
         background: #f7f8fa;
         transition: border 0.2s;
      }
      .box .qty:focus {
         border: 1.5px solid #27ae60;
         outline: none;
      }
      .box .fas.fa-times, .box .fas.fa-edit, .box .fas.fa-eye {
         color: #b2b2b2;
         font-size: 1.2em;
         margin: 0 5px;
         cursor: pointer;
         transition: color 0.2s, background 0.2s;
         background: none;
         border: none;
         border-radius: 50%;
         padding: 7px;
         outline: none;
      }
      .box .fas.fa-times:hover { color: #e74c3c; background: #ffeaea;}
      .box .fas.fa-edit:hover { color: #2980b9; background: #eaf4ff;}
      .box .fas.fa-eye:hover { color: #27ae60; background: #eaffea;}
      .box .fas.fa-eye {
         position: absolute;
         top: 18px;
         left: 18px;
         background: #f7f8fa;
         box-shadow: 0 2px 8px rgba(39,174,96,0.07);
      }
      .box .fas.fa-times {
         position: absolute;
         top: 18px;
         right: 18px;
         background: #f7f8fa;
         box-shadow: 0 2px 8px rgba(231,76,60,0.07);
      }
      .box .sub-total {
         font-size: 1.05em;
         color: #555;
         margin-top: 8px;
         font-weight: 500;
      }
      .btn, .delete-btn {
         display: inline-block;
         padding: 12px 32px;
         border-radius: 8px;
         background: linear-gradient(90deg, #27ae60 0%, #219150 100%);
         color: #fff;
         text-decoration: none;
         font-size: 1.08em;
         margin: 8px 4px;
         border: none;
         cursor: pointer;
         font-weight: 600;
         letter-spacing: 0.5px;
         box-shadow: 0 2px 8px rgba(39,174,96,0.07);
         transition: background 0.2s, box-shadow 0.2s, color 0.2s;
      }
      .btn:hover, .delete-btn:hover {
         background: linear-gradient(90deg, #219150 0%, #27ae60 100%);
         color: #fff;
         box-shadow: 0 4px 16px rgba(39,174,96,0.13);
      }
      .delete-btn {
         background: linear-gradient(90deg, #e74c3c 0%, #c0392b 100%);
         box-shadow: 0 2px 8px rgba(231,76,60,0.07);
      }
      .delete-btn:hover {
         background: linear-gradient(90deg, #c0392b 0%, #e74c3c 100%);
      }
      .disabled, .disabled:hover {
         background: #e0e0e0 !important;
         color: #b2b2b2 !important;
         cursor: not-allowed !important;
         pointer-events: none;
         box-shadow: none !important;
      }
      .cart-total, .more-btn {
         text-align: center;
         margin-top: 32px;
      }
      .cart-total p {
         font-size: 1.35em;
         font-weight: bold;
         color: #222;
         margin-bottom: 18px;
      }
      .empty {
         text-align: center;
         color: #b2b2b2;
         font-size: 1.25em;
         margin: 40px 0;
         font-weight: 500;
      }
      @media (max-width: 900px) {
         .box-container {
            gap: 20px;
         }
         .box {
            width: 90vw;
            max-width: 400px;
         }
      }
      @media (max-width: 600px) {
         .products .title {
            font-size: 1.3em;
         }
         .box {
            padding: 18px 8px 14px 8px;
         }
         .cart-total, .more-btn {
            margin-top: 18px;
         }
      }
   </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<div class="heading">
   <h3>Shopping Cart</h3>
   <p><a href="home.php">Home</a> <span> / Cart</span></p>
</div>

<?php
if(!empty($message)){
   foreach($message as $msg){
      echo '<div class="message">'.htmlspecialchars($msg).'</div>';
   }
}
?>

<section class="products">
   <h1 class="title">Your Cart</h1>
   <div class="box-container">
      <?php
         $grand_total = 0;
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
      ?>
      <form action="" method="post" class="box">
         <input type="hidden" name="cart_id" value="<?= htmlspecialchars($fetch_cart['id']); ?>">
         <a href="quick_view.php?pid=<?= urlencode($fetch_cart['pid']); ?>" class="fas fa-eye" title="Quick View" tabindex="0"></a>
         <button type="submit" class="fas fa-times" name="delete" title="Delete" onclick="return confirm('Delete this item?');" tabindex="0"></button>
         <img src="uploaded_img/<?= htmlspecialchars($fetch_cart['image']); ?>" alt="">
         <div class="name"><?= htmlspecialchars($fetch_cart['name']); ?></div>
         <div class="flex">
            <div class="price"><span>Rp</span><?= number_format($fetch_cart['price'], 2); ?></div>
            <input type="number" name="qty" class="qty" min="1" max="99" value="<?= htmlspecialchars($fetch_cart['quantity']); ?>" maxlength="2">
            <button type="submit" class="fas fa-edit" name="update_qty" title="Update Quantity" tabindex="0"></button>
         </div>
         <div class="sub-total">Sub total: <span>Rp<?= number_format($sub_total = $fetch_cart['price'] * $fetch_cart['quantity'], 2); ?></span></div>
      </form>
      <?php
               $grand_total += $sub_total;
            }
         }else{
            echo '<p class="empty">Your cart is empty</p>';
         }
      ?>
   </div>

   <div class="cart-total">
      <p>Cart total: <span>Rp<?= number_format($grand_total, 2); ?></span></p>
      <a href="checkout.php" class="btn <?= ($grand_total > 0)?'':'disabled'; ?>">Proceed to Checkout</a>
   </div>

   <div class="more-btn">
      <form action="" method="post" style="display:inline;">
         <button type="submit" class="delete-btn <?= ($grand_total > 0)?'':'disabled'; ?>" name="delete_all" onclick="return confirm('Delete all from cart?');">Delete All</button>
      </form>
      <a href="menu.php" class="btn">Continue Shopping</a>
   </div>
</section>

<?php include 'components/footer.php'; ?>
<script src="js/script.js"></script>
<script>
   // Auto-hide messages after 2.5s
   setTimeout(function(){
      document.querySelectorAll('.message').forEach(function(msg){
         msg.style.display = 'none';
      });
   }, 2500);
</script>
</body>
</html>