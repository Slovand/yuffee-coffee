<?php
include __DIR__ . '/components/connect.php';
session_start();
$user_id = $_SESSION['user_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About | Yuffee Coffee and Eatery</title>
   <link rel="icon" href="images/favicon.ico" type="image/x-icon">
   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      :root {
         --primary: #7c4f1d;
         --secondary: #ffe5b4;
         --accent: #a67c52;
         --bg: #f8f6f3;
         --white: #fff;
         --shadow: 0 4px 24px rgba(0,0,0,0.08);
         --radius: 18px;
         --transition: 0.2s cubic-bezier(.4,0,.2,1);
      }
      body {
         background: var(--bg);
         font-family: 'Segoe UI', Arial, sans-serif;
         color: #333;
         margin: 0;
         padding: 0;
      }
      .heading {
         background: linear-gradient(90deg, var(--secondary) 0%, var(--white) 100%);
         padding: 2.5rem 0 2rem 0;
         text-align: center;
         margin-bottom: 2.5rem;
         border-radius: 0 0 var(--radius) var(--radius);
         box-shadow: var(--shadow);
         position: relative;
         overflow: hidden;
      }
      .heading::after {
         content: "";
         position: absolute;
         left: 0; right: 0; bottom: 0;
         height: 8px;
         background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
         opacity: 0.08;
      }
      .heading h3 {
         font-size: 2.8rem;
         color: var(--primary);
         margin-bottom: 0.5rem;
         letter-spacing: 1px;
         font-weight: 700;
      }
      .heading p {
         color: var(--accent);
         font-size: 1.15rem;
         margin: 0;
      }
      .heading a {
         color: var(--primary);
         text-decoration: none;
         font-weight: 600;
         transition: color var(--transition);
      }
      .heading a:hover {
         color: var(--accent);
      }
      .about .row {
         display: flex;
         flex-wrap: wrap;
         align-items: center;
         gap: 2.5rem;
         background: var(--white);
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         padding: 2.5rem 2rem;
         margin: 2.5rem auto 0 auto;
         max-width: 1100px;
         position: relative;
      }
      .about .image {
         flex: 1 1 340px;
         display: flex;
         justify-content: center;
         align-items: center;
      }
      .about .image img {
         width: 340px;
         max-width: 100%;
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         object-fit: cover;
         background: #f3e7d8;
         border: 4px solid #fff;
      }
      .about .content {
         flex: 2 1 400px;
         padding: 1rem 2rem;
         display: flex;
         flex-direction: column;
         justify-content: center;
      }
      .about .content h3 {
         font-size: 2.2rem;
         color: var(--primary);
         margin-bottom: 1.2rem;
         font-weight: 700;
         letter-spacing: 0.5px;
      }
      .about .content p {
         font-size: 1.13rem;
         color: #555;
         margin-bottom: 1.7rem;
         line-height: 1.8;
         text-align: justify;
      }
      .about .btn {
         background: linear-gradient(90deg, var(--primary) 60%, var(--accent) 100%);
         color: var(--white);
         padding: 0.9rem 2.3rem;
         border-radius: 30px;
         text-decoration: none;
         font-weight: 700;
         font-size: 1.08rem;
         letter-spacing: 0.5px;
         box-shadow: 0 2px 8px rgba(124,79,29,0.08);
         border: none;
         transition: background var(--transition), transform var(--transition);
         display: inline-block;
      }
      .about .btn:hover {
         background: linear-gradient(90deg, var(--accent) 0%, var(--primary) 100%);
         transform: translateY(-2px) scale(1.04);
      }
      .steps {
         background: #fff8f0;
         padding: 3.5rem 0 3rem 0;
         margin-top: 2.5rem;
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         max-width: 1200px;
         margin-left: auto;
         margin-right: auto;
      }
      .steps .title {
         text-align: center;
         font-size: 2.2rem;
         color: var(--primary);
         margin-bottom: 2.5rem;
         letter-spacing: 1px;
         font-weight: 700;
      }
      .steps .box-container {
         display: flex;
         flex-wrap: wrap;
         justify-content: center;
         gap: 2.2rem;
         max-width: 1100px;
         margin: 0 auto;
      }
      .steps .box {
         background: var(--white);
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         padding: 2.2rem 1.5rem 2rem 1.5rem;
         text-align: center;
         flex: 1 1 260px;
         min-width: 260px;
         max-width: 340px;
         transition: transform var(--transition), box-shadow var(--transition);
         position: relative;
         overflow: hidden;
      }
      .steps .box::before {
         content: "";
         position: absolute;
         top: -40px; right: -40px;
         width: 80px; height: 80px;
         background: linear-gradient(135deg, var(--secondary) 0%, var(--white) 100%);
         border-radius: 50%;
         opacity: 0.15;
         z-index: 0;
      }
      .steps .box:hover {
         transform: translateY(-10px) scale(1.04);
         box-shadow: 0 8px 32px rgba(124,79,29,0.10);
      }
      .steps .box img {
         width: 85px;
         margin-bottom: 1.2rem;
         z-index: 1;
         position: relative;
         filter: drop-shadow(0 2px 8px rgba(124,79,29,0.07));
      }
      .steps .box h3 {
         color: var(--accent);
         font-size: 1.25rem;
         margin-bottom: 0.7rem;
         font-weight: 700;
         z-index: 1;
         position: relative;
      }
      .steps .box p {
         color: #555;
         font-size: 1.05rem;
         line-height: 1.7;
         z-index: 1;
         position: relative;
      }
      /* Decorative divider */
      .divider {
         width: 80px;
         height: 4px;
         background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
         border-radius: 2px;
         margin: 2rem auto 0 auto;
         opacity: 0.12;
      }
      @media (max-width: 1100px) {
         .about .row, .steps .box-container {
            max-width: 98vw;
         }
      }
      @media (max-width: 900px) {
         .about .row {
            flex-direction: column;
            text-align: center;
            padding: 2rem 1rem;
         }
         .about .image img {
            width: 95%;
            margin-bottom: 1.5rem;
         }
         .about .content {
            padding: 0;
         }
         .steps .box-container {
            flex-direction: column;
            gap: 1.5rem;
         }
      }
      @media (max-width: 600px) {
         .heading h3 { font-size: 2rem; }
         .about .content h3 { font-size: 1.3rem; }
         .steps .title { font-size: 1.3rem; }
         .about .row, .steps { padding: 1.2rem 0.5rem; }
      }
   </style>
</head>
<body style="background-image: url('images/coffee-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
   <!-- header section starts  -->
   <?php include __DIR__ . '/components/user_header.php'; ?>
   <!-- header section ends -->

   <div class="heading">
      <h3>About Us</h3>
      <p><a href="home.php">Home</a> <span> / About</span></p>
   </div>

   <!-- about section starts  -->
   <section class="about">
      <div class="row">
         <div class="image">
            <img src="images/kopi.jpg" alt="Yuffee Coffee and Eatery">
         </div>
         <div class="content">
            <h3>Why Choose Yuffee Coffee and Eatery?</h3>
            <p>
               Yuffee Coffee and Eatery is your destination for specialty coffee and delicious cuisine in a warm, inviting atmosphere. We prioritize quality in every cup and plate, from handpicked coffee beans to signature dishes and sweet treats. Our aesthetic space and friendly service make Yuffee more than just a place to eat—it's a space to relax, work, and connect. Discover authentic culinary experiences and comfort at Yuffee Coffee and Eatery—where flavor meets coziness.
            </p>
            <a href="menu.php" class="btn"><i class="fa-solid fa-mug-hot"></i> Explore Our Menu</a>
         </div>
      </div>
   </section>
   <!-- about section ends -->

   <div class="divider"></div>

   <!-- steps section starts  -->
   <section class="steps">
      <h1 class="title">Simple Steps</h1>
      <div class="box-container">
         <div class="box">
            <img src="images/step-1.png" alt="Choose Order">
            <h3>Choose Order</h3>
            <p>Select your favorite dishes from Yuffee's diverse menu—ranging from aromatic coffee to hearty meals and delightful snacks.</p>
         </div>
         <div class="box">
            <img src="images/step-2.png" alt="Fast Delivery">
            <h3>Fast Delivery</h3>
            <p>Enjoy fast delivery service so your favorite food and drinks arrive fresh and ready to savor.</p>
         </div>
         <div class="box">
            <img src="images/step-3.png" alt="Enjoy Food">
            <h3>Enjoy Food</h3>
            <p>Relish the best from Yuffee Coffee and Eatery, and experience the blend of taste and comfort that keeps you coming back.</p>
         </div>
      </div>
   </section>
   <!-- steps section ends -->

   <!-- footer section starts  -->
   <?php include __DIR__ . '/components/footer.php'; ?>
   <!-- footer section ends -->

   <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
   <script src="js/script.js"></script>
   <script>
   var swiper = new Swiper(".reviews-slider", {
      loop:true,
      grabCursor: true,
      spaceBetween: 20,
      pagination: {
         el: ".swiper-pagination",
         clickable:true,
      },
      breakpoints: {
         0: { slidesPerView: 1 },
         700: { slidesPerView: 2 },
         1024: { slidesPerView: 3 },
      },
   });
   </script>
</body>
</html>