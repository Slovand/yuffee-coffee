<?php
include 'components/connect.php';
session_start();

$user_id = $_SESSION['user_id'] ?? '';

include 'components/add_cart.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Search Products | Kafe</title>
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         background: linear-gradient(120deg, #f8fafc 0%, #fbeee6 100%);
         min-height: 100vh;
         margin: 0;
         font-family: 'Segoe UI', Arial, sans-serif;
         color: #222;
      }
      .search-form {
         display: flex;
         justify-content: center;
         align-items: center;
         margin: 2.5rem 0 1.5rem 0;
      }
      .search-form form {
         display: flex;
         background: #fff;
         border-radius: 40px;
         box-shadow: 0 4px 24px rgba(0,0,0,0.07);
         padding: 0.7rem 1.5rem;
      }
      .search-form .box {
         border: none;
         outline: none;
         padding: 0.8rem 1.2rem;
         border-radius: 40px 0 0 40px;
         font-size: 1.1rem;
         width: 300px;
         background: transparent;
         color: #222;
      }
      .search-form button {
         border: none;
         background: #ff9800;
         color: #fff;
         padding: 0 1.5rem;
         border-radius: 0 40px 40px 0;
         font-size: 1.3rem;
         cursor: pointer;
         transition: background 0.2s;
      }
      .search-form button:hover {
         background: #e65100;
      }
      .products {
         display: flex;
         justify-content: center;
         align-items: flex-start;
         min-height: 60vh;
         padding-top: 0;
      }
      .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
         gap: 2.2rem;
         width: 92%;
         margin: 0 auto;
      }
      .box {
         background: #fff;
         border-radius: 20px;
         box-shadow: 0 4px 24px rgba(0,0,0,0.08);
         padding: 2rem 1.2rem 1.5rem 1.2rem;
         display: flex;
         flex-direction: column;
         align-items: center;
         position: relative;
         transition: transform 0.18s, box-shadow 0.18s;
      }
      .box:hover {
         transform: translateY(-7px) scale(1.025);
         box-shadow: 0 8px 32px rgba(0,0,0,0.13);
      }
      .box img {
         width: 130px;
         height: 130px;
         object-fit: cover;
         border-radius: 14px;
         margin-bottom: 1.1rem;
         box-shadow: 0 2px 10px rgba(0,0,0,0.07);
         background: #f5f5f5;
      }
      .box .cat {
         background: #ff9800;
         color: #fff;
         padding: 0.25rem 1rem;
         border-radius: 14px;
         font-size: 0.95rem;
         margin-bottom: 0.7rem;
         text-decoration: none;
         letter-spacing: 0.5px;
         transition: background 0.2s;
      }
      .box .cat:hover {
         background: #e65100;
      }
      .box .name {
         font-weight: 700;
         font-size: 1.15rem;
         margin-bottom: 0.6rem;
         text-align: center;
         color: #222;
         letter-spacing: 0.2px;
      }
      .box .flex {
         display: flex;
         align-items: center;
         justify-content: space-between;
         width: 100%;
         margin-top: 0.7rem;
      }
      .box .price {
         color: #ff9800;
         font-size: 1.15rem;
         font-weight: bold;
         letter-spacing: 0.5px;
      }
      .box .qty {
         width: 54px;
         border-radius: 8px;
         border: 1px solid #ddd;
         padding: 0.25rem 0.5rem;
         margin-left: 1.2rem;
         font-size: 1rem;
      }
      .box .fas.fa-eye,
      .box .fas.fa-shopping-cart {
         position: absolute;
         top: 1.2rem;
         font-size: 1.25rem;
         background: #fff;
         border-radius: 50%;
         width: 36px;
         height: 36px;
         display: flex;
         align-items: center;
         justify-content: center;
         box-shadow: 0 2px 8px rgba(0,0,0,0.09);
         transition: background 0.2s, color 0.2s;
         color: #ff9800;
         text-decoration: none;
      }
      .box .fas.fa-eye {
         left: 1.2rem;
      }
      .box .fas.fa-shopping-cart {
         right: 1.2rem;
         border: none;
         cursor: pointer;
      }
      .box .fas.fa-shopping-cart:hover,
      .box .fas.fa-eye:hover {
         background: #ff9800;
         color: #fff;
      }
      .empty {
         text-align: center;
         color: #e65100;
         font-size: 1.25rem;
         margin-top: 2.5rem;
         width: 100%;
         font-weight: 500;
      }
      @media (max-width: 600px) {
         .box-container {
            grid-template-columns: 1fr;
         }
         .search-form .box {
            width: 120px;
         }
      }
   </style>
</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="search-form">
   <form method="post" action="">
      <input type="text" name="search_box" placeholder="Search here..." class="box" required aria-label="Search products">
      <button type="submit" name="search_btn" aria-label="Search"><i class="fas fa-search"></i></button>
   </form>
</section>

<section class="products">
   <div class="box-container">
      <?php
         if(isset($_POST['search_btn'])){
            $search_box = trim($_POST['search_box']);
            if($search_box !== ''){
               $select_products = $conn->prepare("SELECT * FROM `products` WHERE name LIKE ?");
               $search_term = "%$search_box%";
               $select_products->execute([$search_term]);
               if($select_products->rowCount() > 0){
                  while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
      ?>
      <form action="" method="post" class="box">
         <input type="hidden" name="pid" value="<?= htmlspecialchars($fetch_products['id']); ?>">
         <input type="hidden" name="name" value="<?= htmlspecialchars($fetch_products['name']); ?>">
         <input type="hidden" name="price" value="<?= htmlspecialchars($fetch_products['price']); ?>">
         <input type="hidden" name="image" value="<?= htmlspecialchars($fetch_products['image']); ?>">
         <a href="quick_view.php?pid=<?= urlencode($fetch_products['id']); ?>" class="fas fa-eye" title="Quick View"></a>
         <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" title="Add to Cart"></button>
         <img src="uploaded_img/<?= htmlspecialchars($fetch_products['image']); ?>" alt="<?= htmlspecialchars($fetch_products['name']); ?>">
         <a href="category.php?category=<?= urlencode($fetch_products['category']); ?>" class="cat"><?= htmlspecialchars($fetch_products['category']); ?></a>
         <div class="name"><?= htmlspecialchars($fetch_products['name']); ?></div>
         <div class="flex">
            <div class="price"><span>Rp</span><?= htmlspecialchars($fetch_products['price']); ?></div>
            <input type="number" name="qty" class="qty" min="1" max="99" value="1" maxlength="2" aria-label="Quantity">
         </div>
      </form>
      <?php
                  }
               }else{
                  echo '<p class="empty">No products found!</p>';
               }
            }else{
               echo '<p class="empty">Please enter a search term.</p>';
            }
         }
      ?>
   </div>
</section>

<?php include 'components/footer.php'; ?>
<script src="js/script.js"></script>
</body>
</html>
