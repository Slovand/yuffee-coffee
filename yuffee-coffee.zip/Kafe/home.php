<?php
include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>The Outer Clove</title>

   <link rel="icon" href="images/favicon.ico" type="image/x-icon">
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">

   <style>
      :root {
         --primary: #7c4d24;
         --secondary: #f8e7d1;
         --accent: #f7c873;
         --bg: #f9f6f2;
         --white: #fff;
         --shadow: 0 4px 24px rgba(0,0,0,0.08);
         --radius: 1.2rem;
         --font-main: 'Inter', Arial, sans-serif;
      }
      html, body {
         background: linear-gradient(120deg, #f9f6f2 0%, #f7c873 100%);
         font-family: var(--font-main);
         color: #3d2c1e;
         margin: 0;
         padding: 0;
      }
      .hero {
         background: var(--secondary);
         padding: 3rem 0 2rem 0;
         border-radius: 0 0 var(--radius) var(--radius);
         box-shadow: var(--shadow);
         margin-bottom: 2.5rem;
      }
      .hero .swiper {
         max-width: 1100px;
         margin: 0 auto;
      }
      .hero .slide {
         display: flex;
         align-items: center;
         justify-content: space-between;
         gap: 2.5rem;
         padding: 2rem 2.5rem;
         border-radius: var(--radius);
         background: var(--white);
         box-shadow: var(--shadow);
      }
      .hero .content {
         flex: 1;
      }
      .hero .content span {
         color: var(--primary);
         font-weight: 600;
         font-size: 1.1rem;
         letter-spacing: 1px;
         text-transform: uppercase;
      }
      .hero .content h3 {
         font-size: 2.5rem;
         margin: 0.5rem 0 1.5rem 0;
         color: var(--primary);
         font-weight: 700;
         letter-spacing: 1px;
      }
      .hero .btn {
         background: var(--primary);
         color: var(--white);
         padding: 0.7rem 2rem;
         border-radius: 2rem;
         font-weight: 600;
         text-decoration: none;
         transition: background 0.2s;
         box-shadow: 0 2px 8px rgba(124,77,36,0.08);
      }
      .hero .btn:hover {
         background: var(--accent);
         color: var(--primary);
      }
      .hero .image img {
         max-width: 220px;
         border-radius: var(--radius);
         box-shadow: 0 2px 12px rgba(0,0,0,0.07);
         background: #fff;
      }
      .swiper-pagination-bullet {
         background: var(--primary) !important;
         opacity: 0.5;
      }
      .swiper-pagination-bullet-active {
         opacity: 1;
      }

      .category {
         position: relative;
         background-image: url('images/food-1024x683.jpg');
         background-size: cover;
         background-position: center;
         padding: 4rem 0 5rem 0;
         overflow: hidden;
         border-radius: var(--radius);
         margin: 2rem 0;
         box-shadow: var(--shadow);
      }
      .category::before {
         content: "";
         position: absolute;
         top: 0; left: 0; width: 100%; height: 100%;
         background: rgba(255,255,255,0.7);
         backdrop-filter: blur(8px);
         z-index: 0;
      }
      .category .title {
         color: var(--primary);
         text-align: center;
         font-size: 2.5rem;
         margin-bottom: 2.5rem;
         position: relative;
         z-index: 2;
         font-weight: 700;
         letter-spacing: 1px;
         text-shadow: 0 2px 8px rgba(0,0,0,0.08);
      }
      .category .box-container {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
         gap: 2rem;
         justify-items: center;
         max-width: 1000px;
         margin: 0 auto;
         padding: 0 1rem;
         position: relative;
         z-index: 1;
      }
      .category .box {
         background: var(--white);
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         padding: 2.2rem 1.8rem;
         text-align: center;
         transition: transform 0.22s, box-shadow 0.22s, background 0.3s;
         width: 100%;
         max-width: 220px;
         position: relative;
         z-index: 2;
         cursor: pointer;
         border: 2px solid transparent;
      }
      .category .box img {
         width: 80px;
         margin-bottom: 1.2rem;
         filter: drop-shadow(0 2px 8px rgba(0,0,0,0.07));
      }
      .category .box h3 {
         font-size: 1.2rem;
         color: var(--primary);
         margin: 0;
         letter-spacing: 1px;
         font-weight: 600;
      }
      .category .box:hover {
         background: var(--accent);
         transform: translateY(-10px) scale(1.045);
         box-shadow: 0 8px 32px rgba(0,0,0,0.13);
         border-color: var(--primary);
      }

      .products {
         padding: 4rem 0 3rem 0;
         background: var(--bg);
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         margin-bottom: 2rem;
      }
      .products .title {
         color: var(--primary);
         text-align: center;
         font-size: 2.2rem;
         margin-bottom: 2.2rem;
         font-weight: 700;
         letter-spacing: 1px;
      }
      .products .box-container {
         display: flex;
         flex-wrap: wrap;
         gap: 2.2rem;
         justify-content: center;
      }
      .products .box {
         background: var(--white);
         border-radius: var(--radius);
         box-shadow: var(--shadow);
         padding: 1.7rem 1.3rem 1.3rem 1.3rem;
         width: 260px;
         display: flex;
         flex-direction: column;
         align-items: center;
         position: relative;
         transition: box-shadow 0.2s, transform 0.2s;
      }
      .products .box:hover {
         box-shadow: 0 8px 32px rgba(0,0,0,0.13);
         transform: translateY(-8px) scale(1.03);
      }
      .products .box img {
         width: 110px;
         margin-bottom: 1.1rem;
         border-radius: 0.7rem;
         background: #f7f7f7;
         box-shadow: 0 2px 8px rgba(0,0,0,0.07);
      }
      .products .cat {
         display: inline-block;
         background: var(--accent);
         color: var(--primary);
         font-size: 0.95rem;
         padding: 0.3rem 1rem;
         border-radius: 1rem;
         margin-bottom: 0.7rem;
         text-decoration: none;
         font-weight: 600;
         transition: background 0.2s;
      }
      .products .cat:hover {
         background: var(--primary);
         color: var(--white);
      }
      .products .name {
         font-size: 1.15rem;
         font-weight: 600;
         color: #3d2c1e;
         margin-bottom: 0.8rem;
         text-align: center;
      }
      .products .flex {
         display: flex;
         align-items: center;
         justify-content: space-between;
         width: 100%;
         margin-top: 0.5rem;
      }
      .products .price {
         font-size: 1.1rem;
         color: var(--primary);
         font-weight: 700;
      }
      .products .qty {
         width: 48px;
         padding: 0.3rem 0.5rem;
         border-radius: 0.7rem;
         border: 1px solid #e0c9b2;
         font-size: 1rem;
         text-align: center;
         margin-left: 0.7rem;
      }
      .products .fas.fa-eye,
      .products .fas.fa-shopping-cart {
         position: absolute;
         top: 1.1rem;
         font-size: 1.2rem;
         color: var(--primary);
         background: var(--accent);
         border-radius: 50%;
         width: 36px;
         height: 36px;
         display: flex;
         align-items: center;
         justify-content: center;
         transition: background 0.2s, color 0.2s;
         cursor: pointer;
         z-index: 3;
      }
      .products .fas.fa-eye {
         left: 1.1rem;
      }
      .products .fas.fa-shopping-cart {
         right: 1.1rem;
         border: none;
         outline: none;
      }
      .products .fas.fa-eye:hover,
      .products .fas.fa-shopping-cart:hover {
         background: var(--primary);
         color: var(--white);
      }
      .products .empty {
         text-align: center;
         color: #b0a08b;
         font-size: 1.1rem;
         margin: 2rem 0;
      }
      .more-btn {
         text-align: center;
         margin-top: 2.5rem;
      }
      .more-btn .btn {
         background: var(--primary);
         color: var(--white);
         padding: 0.7rem 2.2rem;
         border-radius: 2rem;
         font-weight: 600;
         text-decoration: none;
         transition: background 0.2s;
         box-shadow: 0 2px 8px rgba(124,77,36,0.08);
      }
      .more-btn .btn:hover {
         background: var(--accent);
         color: var(--primary);
      }

      @media (max-width: 1100px) {
         .hero .slide {
            flex-direction: column;
            text-align: center;
            gap: 1.5rem;
         }
         .hero .image img {
            max-width: 180px;
         }
      }
      @media (max-width: 900px) {
         .category .box-container {
            grid-template-columns: repeat(2, 1fr);
         }
         .products .box-container {
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
         }
         .products .box {
            width: 90%;
            margin-bottom: 1.5rem;
         }
      }
      @media (max-width: 600px) {
         .hero,
         .category,
         .products {
            padding: 1.2rem 0.2rem;
         }
         .category .title,
         .products .title {
            font-size: 1.5rem;
         }
         .category .box-container {
            grid-template-columns: 1fr;
         }
      }
   </style>
</head>

<body style="background-image: url('images/coffee-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

<?php include 'components/user_header.php'; ?>

<section class="hero">
   <div class="swiper hero-slider">
      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <div class="content">
               <span>order online</span>
               <h3>Yuffee Cafe and Eatery</h3>
               <a href="menu.php" class="btn">see menus</a>
            </div>
            <div class="image">
               <img src="images/home-img-1.png" alt="">
            </div>
         </div>

         <div class="swiper-slide slide">
            <div class="content">
               <span>order online</span>
               <h3>chezzy hamburger</h3>
               <a href="menu.php" class="btn">see menus</a>
            </div>
            <div class="image">
               <img src="images/home-img-2.png" alt="">
            </div>
         </div>

         <div class="swiper-slide slide">
            <div class="content">
               <span>order online</span>
               <h3>roasted chicken</h3>
               <a href="menu.php" class="btn">see menus</a>
            </div>
            <div class="image">
               <img src="images/home-img-3.png" alt="">
            </div>
         </div>

      </div>
      <div class="swiper-pagination"></div>
   </div>
</section>

<section class="products">
   <h1 class="title">food category</h1>
   <div class="box-container">
      <a href="category.php?category=fast food" class="box">
         <img src="images/cat-1.png" alt="">
         <h3>fast food</h3>
      </a>
      <a href="category.php?category=main dish" class="box">
         <img src="images/cat-2.png" alt="">
         <h3>main dishes</h3>
      </a>
      <a href="category.php?category=drinks" class="box">
         <img src="images/cat-3.png" alt="">
         <h3>drinks</h3>
      </a>
      <a href="category.php?category=desserts" class="box">
         <img src="images/cat-4.png" alt="">
         <h3>desserts</h3>
      </a>
   </div>
</section>

<section class="products">
   <h1 class="title">latest dishes</h1>
   <div class="box-container">
      <?php
         $select_products = $conn->prepare("SELECT * FROM `products` LIMIT 6");
         $select_products->execute();
         if($select_products->rowCount() > 0){
            while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
      ?>
      <form action="" method="post" class="box">
         <input type="hidden" name="pid" value="<?= $fetch_products['id']; ?>">
         <input type="hidden" name="name" value="<?= $fetch_products['name']; ?>">
         <input type="hidden" name="price" value="<?= $fetch_products['price']; ?>">
         <input type="hidden" name="image" value="<?= $fetch_products['image']; ?>">
         <a href="quick_view.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye" title="Quick View"></a>
         <button type="submit" class="fas fa-shopping-cart" name="add_to_cart" title="Add to Cart"></button>
         <img src="uploaded_img/<?= $fetch_products['image']; ?>" alt="">
         <a href="category.php?category=<?= $fetch_products['category']; ?>" class="cat"><?= $fetch_products['category']; ?></a>
         <div class="name"><?= $fetch_products['name']; ?></div>
         <div class="flex">
            <div class="price"><span>Rp</span><?= $fetch_products['price']; ?></div>
            <input type="number" name="qty" class="qty" min="1" max="99" value="1" maxlength="2">
         </div>
      </form>
      <?php
            }
         }else{
            echo '<p class="empty">no products added yet!</p>';
         }
      ?>
   </div>
   <div class="more-btn">
      <a href="menu.php" class="btn">view all</a>
   </div>
</section>

<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>
<script>
var swiper = new Swiper(".hero-slider", {
   loop:true,
   grabCursor: true,
   effect: "flip",
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
});
</script>
</body>
</html>