<?php
include 'components/connect.php';
session_start();

$user_id = $_SESSION['user_id'] ?? '';

if(!$user_id){
    header('location:login.php');
    exit;
}

// Inisialisasi variabel
$address = '';
$message = [];

// Ambil data alamat yang sudah ada
$select_address = $conn->prepare("SELECT address FROM `users` WHERE id = ?");
$select_address->execute([$user_id]);
$address_data = $select_address->fetch(PDO::FETCH_ASSOC);

if($address_data){
    $address = $address_data['address'] ?? '';
}

// Proses form update
if(isset($_POST['submit'])){
    $flat = trim($_POST['flat']);
    $building = trim($_POST['building']);
    $area = trim($_POST['area']);
    $town = trim($_POST['town']);
    $city = trim($_POST['city']);
    $state = trim($_POST['state']);
    $country = trim($_POST['country']);
    $pin_code = trim($_POST['pin_code']);

    if(empty($pin_code) || !is_numeric($pin_code)){
        $message[] = 'Kode pos harus berupa angka!';
    } else {
        // Format alamat menjadi satu string
        $formatted_address = "Flat/No: $flat, Gedung: $building, Area: $area, Kecamatan: $town, Kota: $city, Provinsi: $state, Negara: $country, Kode Pos: $pin_code";
        
        try {
            $update_address = $conn->prepare("UPDATE `users` SET address = ? WHERE id = ?");
            $update_address->execute([$formatted_address, $user_id]);

            if($update_address->rowCount() > 0){
                $message[] = 'Alamat berhasil diperbarui!';
                header("refresh:2;url=profile.php"); // Redirect setelah 2 detik
            } else {
                $message[] = 'Tidak ada perubahan data.';
            }
        } catch(PDOException $e) {
            $message[] = 'Error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Address</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="css/style.css">
   <link rel="icon" href="images/iconyuffee.png" type="image/x-icon">
   <style>
      body {
         min-height: 100vh;
         margin: 0;
         background: linear-gradient(135deg, #e0e7ff 0%, #f8fafc 100%);
         font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         display: flex;
         flex-direction: column;
      }
      .form-container {
         max-width: 420px;
         margin: 48px auto 32px auto;
         background: #fff;
         border-radius: 18px;
         box-shadow: 0 8px 32px rgba(80, 80, 180, 0.10), 0 1.5px 4px rgba(0,0,0,0.04);
         padding: 38px 32px 30px 32px;
         position: relative;
         z-index: 1;
      }
      .form-container h3 {
         text-align: center;
         margin-bottom: 28px;
         color: #232946;
         font-size: 1.7rem;
         font-weight: 600;
         letter-spacing: 0.5px;
      }
      .form-container .box {
         width: 100%;
         padding: 13px 15px;
         margin-bottom: 18px;
         border: 1.5px solid #e5e7eb;
         border-radius: 8px;
         font-size: 1.05rem;
         background: #f4f6fb;
         transition: border 0.2s, box-shadow 0.2s;
         color: #232946;
         box-sizing: border-box;
      }
      .form-container .box:focus {
         border-color: #6366f1;
         background: #fff;
         box-shadow: 0 0 0 2px #6366f122;
         outline: none;
      }
      .form-container .btn {
         width: 100%;
         padding: 13px;
         background: linear-gradient(90deg, #6366f1 0%, #38bdf8 100%);
         color: #fff;
         border: none;
         border-radius: 8px;
         font-size: 1.13rem;
         font-weight: 600;
         cursor: pointer;
         transition: background 0.2s, box-shadow 0.2s;
         box-shadow: 0 2px 8px rgba(99,102,241,0.08);
         letter-spacing: 0.5px;
      }
      .form-container .btn:hover {
         background: linear-gradient(90deg, #38bdf8 0%, #6366f1 100%);
         box-shadow: 0 4px 16px rgba(56,189,248,0.10);
      }
      .message {
         background: linear-gradient(90deg, #d1fae5 0%, #e0f2fe 100%);
         color: #047857;
         border: 1.5px solid #a7f3d0;
         padding: 12px 18px;
         border-radius: 8px;
         margin-bottom: 22px;
         text-align: center;
         font-size: 1.05rem;
         font-weight: 500;
         box-shadow: 0 1px 4px rgba(16,185,129,0.06);
      }
      @media (max-width: 600px) {
         .form-container {
            max-width: 98vw;
            padding: 22px 8px 18px 8px;
         }
         .form-container h3 {
            font-size: 1.2rem;
         }
      }
   </style>
</head>
<body>
   
<?php include 'components/user_header.php' ?>

<section class="form-container">
   <?php
   if(!empty($message)){
      foreach($message as $msg){
         echo '<div class="message">'.htmlspecialchars($msg).'</div>';
      }
   }
   ?>

   <form action="" method="post" autocomplete="off">
      <h3><i class="fa-solid fa-location-dot" style="color:#6366f1;margin-right:8px;"></i>Update Alamat Anda</h3>
      <input type="text" class="box" placeholder="Nomor Rumah" required maxlength="50" name="flat" value="">
      <input type="text" class="box" placeholder="Nama Gedung/Nomor" required maxlength="50" name="building" value="">
      <input type="text" class="box" placeholder="Nama Area" required maxlength="50" name="area" value="">
      <input type="text" class="box" placeholder="Nama Kecamatan" required maxlength="50" name="town" value="">
      <input type="text" class="box" placeholder="Nama Kota" required maxlength="50" name="city" value="">
      <input type="text" class="box" placeholder="Nama Provinsi" required maxlength="50" name="state" value="">
      <input type="text" class="box" placeholder="Nama Negara" required maxlength="50" name="country" value="">
      <input type="text" class="box" placeholder="Kode Pos" required maxlength="10" name="pin_code" value="">
      <input type="submit" value="Simpan Alamat" name="submit" class="btn">
   </form>
</section>

<?php include 'components/footer.php' ?>

<script src="js/script.js"></script>
</body>
</html>